package Clase19.ar.org.centro8.curso.java.test;
import Clase19.ar.org.centro8.curso.java.connectors.Connector;
import java.sql.Connection; //Importo
import java.sql.ResultSet; //Importo
import java.time.LocalTime;
public class TestConnector {
    public static void main(String[] args) {
        System.out.println(LocalTime.now());
        //Creamos un objeto de tipo conection
        //Importamos la coneccion
        try (Connection conn=Connector.getConnection()){
            System.out.println(LocalTime.now()); //Imprimimos la hora con segundos al empezar una vez conectado
            //Devuelve obj resultSet que es un conjunto de registros
            //Importamos resultSet
            //Creamos un objeto sentencia sql, ejecuto la query del tipo select, va tener una devolucion de tipo registro
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next()) //Si hay un registro lo imprimimos
                System.out.println(rs.getString(1));
            else //Sino hay registros "no se pudo conectar"
                System.out.println("No se pudo conectar al server!");
            System.out.println(LocalTime.now()); //Imprimimos la hora con segundos despues de conecter el cunjuto de registros
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No se pudo conectar al server!");
        }
        System.out.println(LocalTime.now()); //Imprimimos la hora con segundos despues de desconectarse
    }
}