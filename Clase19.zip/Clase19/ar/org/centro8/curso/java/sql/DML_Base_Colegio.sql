-- DML Data Manipulation Language
-- use colegio;
insert into cursos (titulo,profesor,dia,turno) values
('PHP','Gomez','LUNES','TARDE'),
('Java','Rios','VIERNES','NOCHE'),
('Jardinerio','Sosa','LUNES','MAÑANA'),
('Javascript','Torres','MARTES','TARDE'),
('HTML','Segovia','JUEVES','TARDE');

insert into alumnos (nombre,apellido,edad,idCurso) values
('Hernan','Fernandez',23,2),
('Lorena','Farias',32,1),
('Javier','Reloco',18,1),
('Melina','Lola',26,4),
('Cristian','Molina',40,1);

select * from cursos;
select * from alumnos;
describe cursos;
describe alumnos;
