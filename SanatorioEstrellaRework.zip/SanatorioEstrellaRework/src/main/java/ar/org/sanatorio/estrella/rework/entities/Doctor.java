/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ar.org.sanatorio.estrella.rework.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Lucas
 */
@Entity
@Table(name = "doctores")
@NamedQueries({
    @NamedQuery(name = "Doctor.findAll", query = "SELECT d FROM Doctor d"),
    @NamedQuery(name = "Doctor.findById", query = "SELECT d FROM Doctor d WHERE d.id = :id"),
    @NamedQuery(name = "Doctor.findByNombre", query = "SELECT d FROM Doctor d WHERE d.nombre = :nombre"),
    @NamedQuery(name = "Doctor.findByApellido", query = "SELECT d FROM Doctor d WHERE d.apellido = :apellido"),
    @NamedQuery(name = "Doctor.findByDni", query = "SELECT d FROM Doctor d WHERE d.dni = :dni"),
    @NamedQuery(name = "Doctor.findByTipoEspecialidad", query = "SELECT d FROM Doctor d WHERE d.tipoEspecialidad = :tipoEspecialidad"),
    @NamedQuery(name = "Doctor.findByDia", query = "SELECT d FROM Doctor d WHERE d.dia = :dia"),
    @NamedQuery(name = "Doctor.findByDiaTurno", query = "SELECT d FROM Doctor d WHERE d.diaTurno = :diaTurno")})
public class Doctor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "apellido")
    private String apellido;
    @Column(name = "dni")
    private Integer dni;
    @Column(name = "tipoEspecialidad")
    private String tipoEspecialidad;
    @Column(name = "dia")
    private String dia;
    @Column(name = "diaTurno")
    private String diaTurno;
    @JoinColumn(name = "idInstitucion", referencedColumnName = "id")
    @ManyToOne
    private Institucion idInstitucion;
    @OneToMany(mappedBy = "idDoctor")
    private Collection<Turno> turnoCollection;

    public Doctor() {
    }

    public Doctor(Integer id) {
        this.id = id;
    }

    public Doctor(Integer id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public Doctor(String nombre, String apellido, Integer dni, String tipoEspecialidad, String dia, String diaTurno) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.tipoEspecialidad = tipoEspecialidad;
        this.dia = dia;
        this.diaTurno = diaTurno;
    }

    public Doctor(Integer id, String nombre, String apellido, Integer dni, String tipoEspecialidad, String dia, String diaTurno) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.tipoEspecialidad = tipoEspecialidad;
        this.dia = dia;
        this.diaTurno = diaTurno;
    }

    public Doctor(String nombre, String apellido, Integer dni, String tipoEspecialidad, String dia, String diaTurno, Institucion idInstitucion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.tipoEspecialidad = tipoEspecialidad;
        this.dia = dia;
        this.diaTurno = diaTurno;
        this.idInstitucion = idInstitucion;
    }

    public Doctor(Integer id, String nombre, String apellido, Integer dni, String tipoEspecialidad, String dia, String diaTurno, Institucion idInstitucion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.tipoEspecialidad = tipoEspecialidad;
        this.dia = dia;
        this.diaTurno = diaTurno;
        this.idInstitucion = idInstitucion;
    }
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Integer getDni() {
        return dni;
    }

    public void setDni(Integer dni) {
        this.dni = dni;
    }

    public String getTipoEspecialidad() {
        return tipoEspecialidad;
    }

    public void setTipoEspecialidad(String tipoEspecialidad) {
        this.tipoEspecialidad = tipoEspecialidad;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getDiaTurno() {
        return diaTurno;
    }

    public void setDiaTurno(String diaTurno) {
        this.diaTurno = diaTurno;
    }

    public Institucion getIdInstitucion() {
        return idInstitucion;
    }

    public void setIdInstitucion(Institucion idInstitucion) {
        this.idInstitucion = idInstitucion;
    }

    public Collection<Turno> getTurnoCollection() {
        return turnoCollection;
    }

    public void setTurnoCollection(Collection<Turno> turnoCollection) {
        this.turnoCollection = turnoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Doctor)) {
            return false;
        }
        Doctor other = (Doctor) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Doctor{id=").append(id);
        sb.append(", nombre=").append(nombre);
        sb.append(", apellido=").append(apellido);
        sb.append(", dni=").append(dni);
        sb.append(", tipoEspecialidad=").append(tipoEspecialidad);
        sb.append(", dia=").append(dia);
        sb.append(", diaTurno=").append(diaTurno);
        sb.append(", idInstitucion=").append(idInstitucion);
        sb.append('}');
        return sb.toString();
    }
}
