
package ar.org.sanatorio.estrella.rework.enums;


public enum Dia {LUNES,MARTES,MIERCOLES,JUEVES,VIERNES,SABADO,DOMINGO}
