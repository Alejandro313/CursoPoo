package ar.org.sanatorio.estrella.rework.utils.swing;

import java.awt.Component;
import java.lang.reflect.Field;
import java.util.EventObject;
import java.util.List;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.DefaultTableModel;

public class Table <E>{
    //Nos pasa el nombre de table y de la lista que nos va cargar
    public void cargar(JTable tbl, List<E> list){
        if(tbl==null) return;
        //si existia una info en el table se borra
        DefaultTableModel dtm=new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               row = tbl.getSelectedRow();
               column = tbl.getSelectedColumn();
                if(column!=0) return true;
               return false;
            }
        };   
        tbl.setModel(dtm);
        //agregamos las columnas
        if(list==null || list.isEmpty()) return;
        E e=list.get(0);
        Field[] campos=e.getClass().getDeclaredFields();
        for(Field f:campos)dtm.addColumn(f.getName());
        //agregamos las filas
        //Recorro campo por campo
        for(E ee:list){
            Object[] registro=new Object[campos.length];
            for(int a=0;a<campos.length;a++){
                Field f=campos[a];
                String metodo="get"+f.getName().substring(0,1).toUpperCase()+f.getName().substring(1);
                try {
                    registro[a]=e.getClass().getMethod(metodo, null).invoke(ee, null);
                } catch (Exception ex) { ex.printStackTrace();}
            }
            dtm.addRow(registro);
        }
    }
}
