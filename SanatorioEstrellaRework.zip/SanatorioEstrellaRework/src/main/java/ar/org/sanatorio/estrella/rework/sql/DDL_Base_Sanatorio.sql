/*Remote Host: freedb.tech
Port: 3306
Database Name: freedbtech_sanatorio
Username: freedbtech_freedbsanatorio
Password: estrella*/

drop database if exists sanatorio;
create database sanatorio;
use sanatorio;

/*drop table if exists turnos;
drop table if exists doctores;
drop table if exists pacientes;
drop table if exists especialidades;
drop table if exists institucion;

show tables;*/

create table instituciones(
	id int auto_increment primary key, -- FK con especialidades
	nombre varchar (30) not null,
	cuit varchar (15) not null,
	telefono int,
	direccion varchar (50) not null,
	localidad varchar (30) not null,
	provincia varchar (30) not null,
	horario varchar (10) not null
);

create table doctores(
	id int auto_increment primary key, -- FK turnos
	nombre varchar(25) not null,
	apellido varchar(25) not null,
	dni int,
	tipoEspecialidad enum ('GASTROENTEROLOGIA','CARDIOLOGIA','PEDIATRIA','NEUMOLOGIA','ODONTOLOGIA','OFTALMOLOGIA','OTORRINOLARINGOLOGIA','ENDOCRINOLOGIA'),
	dia enum ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'),
	diaTurno enum ('MAÑANA','TARDE'),
	idInstitucion int
);

create table personal(
    id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(24) not null,
    dni int not null,
    cargo enum ('ENFERMERIA','ADMINISTRATIVO','RECEPCIONISTA','LIMPIEZA','ASISTENTE','PARAMEDICO','CAMILLERO','TERAPEUTA','RADIOLOGO','SEGURIDAD'),
    idInstitucion  int
);

create table turnos(
    id int auto_increment primary key,
    idDoctor int, -- KF doctor (id)
    idPaciente int, -- KF pacientes (id)
    fecha varchar (10),
    horario varchar(5),
    idInstitucion  int
);

create table pacientes(
	id int auto_increment primary key,
	nombre varchar(25) not null,
	apellido varchar(25) not null,
	edad int,
	dni int,
	obraSocial varchar (30) not null,
	idInstitucion  int
);

alter table turnos
    add constraint FK_Doctor_Id
    foreign key(idDoctor)
    references doctores(id);

alter table turnos
    add constraint FK_Paciente_Id
    foreign key(idPaciente)
    references pacientes(id);
    
alter table doctores
    add constraint FK_Doctor_idInstituciones
    foreign key(idInstitucion)
    references instituciones(id);
    
alter table personal
    add constraint FK_personal_idInstitucion
    foreign key(idInstitucion)
    references instituciones(id);
    
alter table pacientes
    add constraint FK_pacientes_idInstitucion
    foreign key(idInstitucion)
    references instituciones(id);    
    
alter table turnos
    add constraint FK_turnos_idInstitucion
    foreign key(idInstitucion)
    references instituciones(id);