package ar.org.sanatorio.estrella.rework.test;

import ar.org.sanatorio.estrella.rework.entities.Doctor;
import ar.org.sanatorio.estrella.rework.entities.Institucion;
import java.time.LocalTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestConnector {

    public static void main(String[] args) throws Exception{
        
        time();
        System.out.println("-- Inicia Entity Manager Factory");
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        
        time();
        System.out.println("-- Crea EntityManager");
        EntityManager em=emf.createEntityManager();
        time();
        
        //Doctor doctor=new Doctor("Josefina", "Prado", 37978656, "PEDIATRIA", "MIERCOLES", "MAÑANA",1);
        Institucion insti = new Institucion("Sanatorio Estrella", "24534654", 42123454, "Zapiola", "Quilmes", "Buenos Aires", "24 horas");
        em.getTransaction().begin();
        em.persist(insti);
        em.getTransaction().commit();
        System.out.println(insti);
   
        /*em
        .createNamedQuery("Curso.findAll")
        .getResultList()
        .forEach(System.out::println);
        
        em
        .createNamedQuery("Alumno.findAll")
        .getResultList()
        .forEach(System.out::println);
        
        Query query=em.createNamedQuery("Doctor.findByTipoEspecialidad");
        query.setParameter("tipoEspecialidad", "PEDIATRIA");
        query.getResultList().forEach(System.out::println);
        
        query=em.createNamedQuery("DOCTOR.findLikeApellido");
        query.setParameter("apellido", "%Pr%");
        query.getResultList().forEach(System.out::println);*/
        
        
//        query=em.createNamedQuery("Alumno.findById");
//        query.setParameter("id", 9);
//        Alumno alumno=(Alumno)query.getSingleResult();
//        System.out.println(alumno);
//        
//        em.getTransaction().begin();
//        em.remove(alumno);
//        em.getTransaction().commit();
        
        
        
        time();
        System.out.println("-- Cierra EntityManager");
        em.close();
        time();
        System.out.println("-- Cierra EntityManagerFactory");
        emf.close();
        time();
    }
    
    private static void time(){
        System.out.println("\033[34m****************************************************");
        System.out.println("\033[34m"+LocalTime.now());
        System.out.println("\033[34m****************************************************");

    }
    
}
