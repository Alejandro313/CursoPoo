package ar.org.sanatorio.estrella.rework.test;

import ar.org.sanatorio.estrella.rework.entities.Doctor;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestJPA {
    
    public static void main(String[] args) {
        System.out.println("****************************");
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        EntityManager em=emf.createEntityManager();
        
        Doctor doctor = new Doctor("Josefina", "Prado", 37978656, "PEDIATRIA", "MIERCOLES", "MAÑANA");
        
        em.getTransaction();
        em.persist(doctor);
        em.getTransaction().commit();
     
        em.close();
        emf.close();
        System.out.println("****************************");
    }
}
