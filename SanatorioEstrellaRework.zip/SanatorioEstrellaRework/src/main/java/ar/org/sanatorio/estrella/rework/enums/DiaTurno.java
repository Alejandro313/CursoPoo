package ar.org.sanatorio.estrella.rework.enums;


public enum DiaTurno {MAÑANA,TARDE}
