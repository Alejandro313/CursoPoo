use sanatorio;

/*select * from instituciones;
select * from turnos;
select * from especialidades;
select * from doctores;
select * from pacientes;*/

insert into instituciones (id,nombre, cuit, telefono, direccion,localidad,provincia, horario) values
(1,'Sanatorio Estrella','30-67546356',42765434,'San Martin 503','San Ignacio','Buenos Aires','24 horas');

insert into doctores (nombre,apellido,dni,tipoEspecialidad,dia,diaTurno,idInstitucion ) values
('Mariano','Lopez',24652342,'CARDIOLOGIA','LUNES','MAÑANA',1),
('Oscar','Deluca',26547652,'NEUMOLOGIA','MARTES','MAÑANA',1),
('Carla','Morales',32768754,'PEDIATRIA','LUNES','MAÑANA',1),
('Micaela','Sanchez',31456543,'ODONTOLOGIA','JUEVES','TARDE',1),
('Martin','Perez',34765784,'OFTALMOLOGIA','MIERCOLES','TARDE',1),
('Miranda','Melo','23454365','OTORRINOLARINGOLOGIA','VIERNES','MAÑANA',1),
('Cesar','Cazula','37564343','ENDOCRINOLOGIA','SABADO','MAÑANA',1);

insert into personal(nombre,apellido,dni,cargo,idInstitucion) values
('Andres','Muro',43657453,'ASISTENTE',1),
('Miranda','Diaz',38765674,'ENFERMERIA',1),
('Julio','Zalasar',35674563,'CAMILLERO',1),
('Mauro','Achora',37665453,'ASISTENTE',1),
('Diego','Porsi',32564575,'LIMPIEZA',1),
('Rocio','Merengue',54634523,'LIMPIEZA',1),
('Juan','Ortega',29756323,'PARAMEDICO',1),
('Marcelo','Borge',36754563,'TERAPEUTA',1),
('Matias','Soria',42457623,'SEGURIDAD',1),
('Pablo','Tulio',33764532,'RADIOLOGO',1);

insert into pacientes(nombre,apellido,edad,dni,obraSocial,idInstitucion) values
('Julieta','Pascal',28,34876754,'vital',1),
('Miguel','Diaz',24,41874534,'Ceramista',1),
('Julian','Mendoza',18,44587594,'Borge',1),
('Rodrigo','Palacio',12,45876745,'DIG',1),
('Patricio','Ledezma',17,44987865,'Rido',1),
('David','Merendez',32,27987657,'Vista',1),
('Monica','Silva',29,34765434,'Naranja A',1),
('Dante','Rios',31,26876754,'Conten',1),
('Diana','Fernandez',25,35787654,'Derecha B',1),
('Sandro','Galvan',24,36875643,'Izquierda H',1),
('Sebastian','Molina',36,25432654,'Celeste D',1),
('Brian','Gimenez',40,24765734,'Marmol SR',1);

insert into turnos(idDoctor,idPaciente,fecha,horario) values
(6,1,'2021-06-04','11:00'),
(2,1,'2021-06-10','12:00'),
(2,2,'2021-06-09','08:00'),
(6,2,'2021-06-11','10:00'),
(1,3,'2021-06-07','09:00'),
(5,3,'2021-06-16','15:00'),
(3,4,'2021-06-14','11:00'),
(1,4,'2021-06-07','11:00'),
(5,5,'2021-06-16','15:00'),
(2,5,'2021-06-09','11:00'),
(2,6,'2021-06-10','12:00');