package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;

    public Vehiculo(String marca, String modelo,double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public String getPrecioFormat(){
    DecimalFormat df = new DecimalFormat("###,###.00");
    return df.format(precio);
    }
    
    
   @Override
    public String toString() {
        return "Marca: " + marca+" // " +"Modelo: " + modelo +" // ";
    }
    
    @Override
    public int compareTo(Vehiculo c){
    
        String thisV = this.getMarca()+" "+this.getModelo()+" "+this.getPrecio();
        String cV = c.getMarca()+" "+c.getModelo()+" "+c.getPrecio();
        return thisV.compareTo(cV);
    }

}
