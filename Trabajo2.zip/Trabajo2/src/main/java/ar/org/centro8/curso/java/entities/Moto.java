package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public class Moto extends Vehiculo{
    private String cilindradas;

    public Moto(String marca, String modelo,String cilindradas,double precio) {
        super(marca, modelo, precio);
        this.cilindradas = cilindradas;
        
    }

    public String getCilindradas() {
        return cilindradas;
    }
    
    @Override
    public String toString() {
        return super.toString()+"Cilindradas: "+cilindradas+" // "+"Precio: "+getPrecioFormat();
    }

}
