package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Set;

public class App {
    
    private static Set<Vehiculo>listaVehiculo=new LinkedHashSet();
    //private static List<Vehiculo>listVehiculo=new ArrayList();
    //private static List<Auto>listAuto=new ArrayList();
    //private static List<Moto>listMoto=new ArrayList();
    
    public static void main(String[] args) {
        
        cargar();
        
        Listado();
        
        Separador();
        
        VehiculoMasCaro();
              
        VehiculoMasBarato();
        
        BuscandoModelo();
        
        Separador();
        
        OrdenarMayoryMenorPrecio();
        
        Separador();
        
        OrdenNatural();
                               
    }
    
     private static void Separador() {
        System.out.println("\n\n=============================\n\n");
    }

     private static void cargar(){
        listaVehiculo.add(new Auto("Peugeot", "206", 4,200000));
        listaVehiculo.add(new Auto("Peugeot", "208", 5,250000));
        listaVehiculo.add(new Moto("Honda", "Titan", "125c", 60000));
        listaVehiculo.add(new Moto("Yamaha", "YBR", "160c", 80500));
        
    }
     
    private static void Listado() {
        listaVehiculo
                .stream()
                .forEach(System.out::println);
    }
    
    private static void VehiculoMasCaro() {
        listaVehiculo
                .stream()
                .filter(v->v.getPrecio()==listaVehiculo
                        .stream()
                        .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio()
                )
                
                .forEach(v->System.out.println("Vehiculo más caro: "+
                        v.getMarca()+" "+v.getModelo())
                );
    }

    private static void VehiculoMasBarato() {
         listaVehiculo
                .stream()
                .filter(v->v.getPrecio()==listaVehiculo
                        .stream()
                        .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio()
                )
                
                .forEach(v->System.out.println("Vehiculo más barato: "+
                        v.getMarca()+" "+v.getModelo())
                );
    }

    private static void BuscandoModelo() {
       listaVehiculo
               .stream()
               .filter(v->v.getModelo().toLowerCase().contains("y"))
               .forEach(v->System.out.println("Vehículo que contiene en el modelo la letra ‘Y: "
                       +v.getMarca()+" "+v.getModelo()+" "+v.getPrecio()));
    }

    private static void OrdenarMayoryMenorPrecio() {
        System.out.println("Vehículos ordenados por precio de mayor a menor:\n");
        listaVehiculo
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
    }

    private static void OrdenNatural() {
        System.out.println("Vehículos ordenados por orden natural: \n");
        listaVehiculo
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

    
    
   
   
}
