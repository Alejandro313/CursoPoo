package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public class Auto extends Vehiculo {
    private int Puertas;

    public Auto(String marca, String modelo,int Puertas,double precio) {
        super(marca, modelo,precio);
        this.Puertas = Puertas;
    }

    public int getPuertas() {
        return Puertas;
    }
    
    @Override
    public String toString() {
        return super.toString()+"Puertas: "+Puertas+" // "+"Precio: "+getPrecioFormat();
    } 
    
}
