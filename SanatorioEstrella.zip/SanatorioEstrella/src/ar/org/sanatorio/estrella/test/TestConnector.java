package ar.org.sanatorio.estrella.test;

import ar.org.sanatorio.estrella.connectors.Connector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalTime;

public class TestConnector {
    
    public static void main(String[] args) {
            
        try (Connection conn=Connector.getConnection()) {
            System.out.println(LocalTime.now());
            ResultSet rs=conn.createStatement().executeQuery("select version()");
            if(rs.next())
                System.out.println(rs.getString(1));
            else 
                System.out.println(LocalTime.now());
                System.out.println("No se pudo conectar al server");
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No se pudo conectar al server");
        }
        System.out.println(LocalTime.now());
    }
}