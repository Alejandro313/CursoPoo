package ar.org.sanatorio.estrella.test.repositories;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.entities.Institucion;
import ar.org.sanatorio.estrella.entities.Paciente;
import ar.org.sanatorio.estrella.entities.Turno;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.DiaTurno;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_InstitucionRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_PacienteRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_TurnoRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.InstitucionRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.PacienteRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.TurnoRepository;

public class TestRepositories {
        public static void main (String[] args) {
        I_DoctorRepository doc=new DoctorRepository(Connector.getConnection());
        I_PacienteRepository pac=new PacienteRepository(Connector.getConnection());
        I_TurnoRepository tur=new TurnoRepository(Connector.getConnection());
        I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
        I_InstitucionRepository ins=new InstitucionRepository(Connector.getConnection());
	
        System.out.println("**********INSTITUCION**********");
        ins.getAll().forEach(System.out::println);
        
        System.out.println("\n**********DOCTORES**********\n");
        
        //Agregamos un nuevo doctor
        Doctor doctor = new Doctor("Lorenzo","Gomez",Dia.MIERCOLES,DiaTurno.TARDE,4);
        
        //guardamos a la base el registro del nuevo doctor
        doc.save(doctor);
        
        //actualizamos la base de datos
        doctor=doc.getById(8);
        doctor.setDia(Dia.JUEVES);
        doc.update(doctor);
        
        //eliminamos de la lista a un doctor
        //doc.remove(doc.getById(8));
        //doc.remove(doc.getById(9));
        
        System.out.println("********************************");
        //mostramos a todos los doctores
        doc.getAll().forEach(System.out::println);
        
        System.out.println("********************************");
        System.out.println("Doctor con apellido gomez");
        doc.getLikeApellido("Gomez").forEach(System.out::println);
        
        System.out.println("\n**********PACIENTES**********\n");
        Paciente paciente = new Paciente("Santiago", "Diaz", 24, 34457896, "Arcor Salud");
        
        pac.save(paciente);
        //pac.update(paciente);
        System.out.println("********************************");
        pac.getAll().forEach(System.out::println);
        
        System.out.println("********************************");
        System.out.println("Paciente con apellido que comienze con 'di'");
        pac.getLikeApellido("Di").forEach(System.out::println);
        
        System.out.println("\n**********TURNOS**********\n");
        Turno turno = new Turno(4, 8, "2021-06-10", "13:00");
        
        //tur.save(turno);
        //tur.remove(tur.getById(14));
        //tur.update(turno);
        //System.out.println("********************************");
        tur.getAll().forEach(System.out::println);
        
        System.out.println("********************************");
        System.out.println("Turno con el doctor con id 4");
        tur.getByIdDoctor(4).toString();
        
        System.out.println("\n**********ESPECIALIDAD**********\n");
        Especialidad especialidad = new Especialidad(1, TipoEspecialidad.OTORRINOLARINGOLOGIA);
        
        espe.save(especialidad);
        espe.getAll().forEach(System.out::println);
        //espe.update(especialidad);
        //espe.remove(espe.getById(12));
        
        
        System.out.println("********************************");
        System.out.println("Mostrar si existe la especialidad Otorrinolaringologia");
        espe.getLikeEspecialidad(TipoEspecialidad.OTORRINOLARINGOLOGIA)
        .forEach(System.out::println);
	}
}
