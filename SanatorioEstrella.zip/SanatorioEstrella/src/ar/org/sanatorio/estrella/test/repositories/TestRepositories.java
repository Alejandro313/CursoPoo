package ar.org.sanatorio.estrella.test.repositories;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor_;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;

public class TestRepositories {

	public static void main (String[] args) {
	I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());
	
	Doctor_ doctor = new Doctor_("Lorenzo","Gomez",Dia.MIERCOLES,Turno.TARDE,4);
	
	dr.save(doctor);
	
	System.out.println("********************************");
	
	//dr.getAll().forEach(System.out::println);
	//dr.getLikeApellido("Lopez").forEach(System.out::println);
	}
}
