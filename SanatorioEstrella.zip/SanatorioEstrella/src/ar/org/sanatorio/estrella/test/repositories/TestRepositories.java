package ar.org.sanatorio.estrella.test.repositories;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;

public class TestRepositories {

	public static void main (String[] args) {
	I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());
	
	Doctor doctor = new Doctor("Lorenzo","Gomez",Dia.MIERCOLES,Turno.TARDE,4);
	
	dr.save(doctor);
	dr.remove(dr.getById(2));
	//System.out.println(doctor);
	
	System.out.println("********************************");
	dr.getAll().forEach(System.out::println);
	
	System.out.println("********************************");
	dr.getLikeApellido("Gomez").forEach(System.out::println);
	}
}
