package ar.org.sanatorio.estrella.test.repositories;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;

public class TestRepositories {

	public static void main (String[] args) {
	I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());
	
	//Agregamos un nuevo doctor
	Doctor doctor = new Doctor("Lorenzo","Gomez",Dia.MIERCOLES,Turno.TARDE,4);
	
	//guardamos a la base el registro del nuevo doctor
	//dr.save(doctor);
	
	//actualizamos la base de datos
	doctor=dr.getById(13);
	doctor.setDia(Dia.JUEVES);
	dr.update(doctor);
	
	//eliminamos de la lista a un doctor
	//dr.remove(dr.getById(16));
	
	//System.out.println("********************************");
	
	//mostramos a todos los doctores
	//dr.getAll().forEach(System.out::println);
	
	//System.out.println("********************************");
	
	//System.out.println("Doctor con apellido gomez: ");
	dr.getLikeApellido("Gomez").forEach(System.out::println);
	
	//System.out.println("*******************************");
	
	}
}
