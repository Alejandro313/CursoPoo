package ar.org.sanatorio.estrella.entities;


public class Pacientes {
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int dni;
    private String obra_social;
	
    public Pacientes() {
	
	}

	public Pacientes(String nombre, String apellido, int edad, int dni, String obra_social) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.dni = dni;
		this.obra_social = obra_social;
	}

	public Pacientes(int id, String nombre, String apellido, int edad, int dni, String obra_social) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.dni = dni;
		this.obra_social = obra_social;
	}

	@Override
	public String toString() {
		return "Pacientes [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", dni="
				+ dni + ", obra_social=" + obra_social + "]";
	}
    
}
