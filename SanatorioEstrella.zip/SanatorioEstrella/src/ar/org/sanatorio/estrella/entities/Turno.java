package ar.org.sanatorio.estrella.entities;

public class Turno{
	private int id;
	private int idDoctor;
	private int idPaciente;
	private String fecha;
	private String horario;
	
	public Turno() {
	}
	
	public Turno(int idDoctor, int idPaciente, String fecha, String horario) {
		this.idDoctor = idDoctor;
		this.idPaciente = idPaciente;
		this.fecha = fecha;
		this.horario = horario;
	}
	
	public Turno(int id, int idDoctor, int idPaciente, String fecha, String horario) {
		this.id = id;
		this.idDoctor = idDoctor;
		this.idPaciente = idPaciente;
		this.fecha = fecha;
		this.horario = horario;
	}
	
	@Override
	public String toString() {
		return "id: " + id + "\nIdDoctor: " + idDoctor + "\nIdPaciente: " + idPaciente + "\nFecha=" + fecha
				+ "\nHorario=" + horario+"\n*************************";
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getIdDoctor() {
		return idDoctor;
	}
	
	public void setIdDoctor(int idDoctor) {
		this.idDoctor = idDoctor;
	}
	
	public int getIdPaciente() {
		return idPaciente;
	}
	
	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	public String getHorario() {
		return horario;
	}
	
	public void setHorario(String horario) {
		this.horario = horario;
	}
}