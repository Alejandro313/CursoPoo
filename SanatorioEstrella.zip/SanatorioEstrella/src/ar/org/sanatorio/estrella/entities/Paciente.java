package ar.org.sanatorio.estrella.entities;


public class Paciente {
    
    int id;
    String nombre;
    String apellido;
    int turno;
    //time
    
    
}
