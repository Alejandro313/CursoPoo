package ar.org.sanatorio.estrella.entities;


public class Paciente{
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int dni;
    private String obra_social;
	
    public Paciente() {
	}

	public Paciente(String nombre, String apellido, int edad, int dni, String obra_social) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.dni = dni;
		this.obra_social = obra_social;
	}

	public Paciente(int id, String nombre, String apellido, int edad, int dni, String obra_social) {
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.dni = dni;
		this.obra_social = obra_social;
	}

	@Override
	public String toString() {
		return "Pacientes [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", dni="
				+ dni + ", obra_social=" + obra_social + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public String getObra_social() {
		return obra_social;
	}

	public void setObra_social(String obra_social) {
		this.obra_social = obra_social;
	}
    
	
}
