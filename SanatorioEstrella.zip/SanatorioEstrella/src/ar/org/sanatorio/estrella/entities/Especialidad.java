package ar.org.sanatorio.estrella.entities;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;

public class Especialidad{
	private int id;
    private int id_institucion;
	private TipoEspecialidad especialidad;
	
	public Especialidad() {
	}
	
	public Especialidad(int id_institucion, TipoEspecialidad especialidad) {
		this.id_institucion = id_institucion;
		this.especialidad = especialidad;
	}
	
	public Especialidad(int id, int id_institucion, TipoEspecialidad especialidad) {
		this.id = id;
		this.id_institucion = id_institucion;
		this.especialidad = especialidad;
	}
	
	@Override
	public String toString() {
		return "Especialidades [id=" + id + ", id_institucion=" + id_institucion + ", especialidad=" + especialidad
				+ "]";
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId_institucion() {
		return id_institucion;
	}
	
	public void setId_institucion(int id_institucion) {
		this.id_institucion = id_institucion;
	}
	
	public TipoEspecialidad getEspecialidad() {
		return especialidad;
	}
	
	public void setTipoEspecialidad(TipoEspecialidad especialidad) {
		this.especialidad = especialidad;
	}
}
