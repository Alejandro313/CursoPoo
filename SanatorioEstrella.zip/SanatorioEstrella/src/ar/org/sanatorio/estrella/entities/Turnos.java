package ar.org.sanatorio.estrella.entities;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

import ar.org.sanatorio.estrella.enums.Horario;

public class Turnos {
	int id;
	int idDoctor;
	int idPaciente;
	LocalDate fecha; //"LocalDate.of(a�o, mes, dia);"
	Horario horario;

	public Turnos() {

	}

}
