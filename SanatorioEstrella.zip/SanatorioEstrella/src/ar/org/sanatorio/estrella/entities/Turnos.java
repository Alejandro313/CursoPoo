package ar.org.sanatorio.estrella.entities;

public class Turnos {
    
}
