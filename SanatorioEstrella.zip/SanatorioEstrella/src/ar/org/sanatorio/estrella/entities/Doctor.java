package ar.org.sanatorio.estrella.entities;

import ar.org.sanatorio.estrella.enums.Especialidad;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;


public class Doctor {
    private int id;
    private Especialidad especialidad;
    private String nombre;
    private String apellido;
    private Dia dia;
    private Turno turno;

    public Doctor() {
    }

    public Doctor(Especialidad especialidad, String nombre, String apellido, Dia dia, Turno turno) {
        this.especialidad = especialidad;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dia = dia;
        this.turno = turno;
    }

    public Doctor(int id, Especialidad especialidad, String nombre, String apellido, Dia dia, Turno turno) {
        this.id = id;
        this.especialidad = especialidad;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dia = dia;
        this.turno = turno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Especialidad getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(Especialidad especialidad) {
        this.especialidad = especialidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }

    public Turno getTurno() {
        return turno;
    }

    public void setTurno(Turno turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Doctor:" + "id=" + id + ", especialidad=" + especialidad + ", nombre=" + nombre + ", apellido=" + apellido + ", dia=" + dia + ", turno=" + turno + '}';
    }
    
}
