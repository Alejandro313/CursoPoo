package ar.org.sanatorio.estrella.entities;

import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;

public class Doctor {
	private int id;
	private String nombre;
	private String apellido;
	private Dia dia;
	private Turno turno;
	private int idEspecialidad;
	
    public Doctor() {
    }
    
	public Doctor(String nombre, String apellido, Dia dia, Turno turno, int idEspecialidad) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.dia = dia;
		this.turno = turno;
		this.idEspecialidad = idEspecialidad;
	}

	public Doctor(int id, String nombre, String apellido, Dia dia, Turno turno, int idEspecialidad) {
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dia = dia;
		this.turno = turno;
		this.idEspecialidad = idEspecialidad;
	}

	@Override
	public String toString() {
		return "Doctores [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", dia=" + dia + ", turno="
				+ turno + ", idEspecialidad=" + idEspecialidad + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Dia getDia() {
		return dia;
	}

	public void setDia(Dia dia) {
		this.dia = dia;
	}

	public Turno getTurno() {
		return turno;
	}

	public void setTurno(Turno turno) {
		this.turno = turno;
	}

	public int getIdEspecialidad() {
		return idEspecialidad;
	}

	public void setIdEspecialidad(int idEspecialidad) {
		this.idEspecialidad = idEspecialidad;
	}

}
