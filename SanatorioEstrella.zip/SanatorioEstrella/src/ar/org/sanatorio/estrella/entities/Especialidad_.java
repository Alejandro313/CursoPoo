package ar.org.sanatorio.estrella.entities;
import ar.org.sanatorio.estrella.enums.Especialidad;

public class Especialidad_ {
	private int id;
    private int id_institucion;
	private Especialidad especialidad;
	
	public Especialidad_() {
	
	}
	
	public Especialidad_(int id_institucion, Especialidad especialidad) {
		this.id_institucion = id_institucion;
		this.especialidad = especialidad;
	}
	
	public Especialidad_(int id, int id_institucion, Especialidad especialidad) {
		this.id = id;
		this.id_institucion = id_institucion;
		this.especialidad = especialidad;
	}
	
	@Override
	public String toString() {
		return "Especialidades [id=" + id + ", id_institucion=" + id_institucion + ", especialidad=" + especialidad
				+ "]";
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId_institucion() {
		return id_institucion;
	}
	
	public void setId_institucion(int id_institucion) {
		this.id_institucion = id_institucion;
	}
	
	public Especialidad getEspecialidad() {
		return especialidad;
	}
	
	public void setEspecialidad(Especialidad especialidad) {
		this.especialidad = especialidad;
	}

}
