package ar.org.sanatorio.estrella.entities;

import ar.org.sanatorio.estrella.enums.Especialidad;
public class Especialidades {
    
	int id;
    int id_institucion;
	Especialidad especialidad;
}
