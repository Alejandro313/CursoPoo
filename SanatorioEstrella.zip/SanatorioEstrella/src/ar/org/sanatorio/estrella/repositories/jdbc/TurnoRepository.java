package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.sanatorio.estrella.entities.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_TurnoRepository;

public class TurnoRepository implements I_TurnoRepository{

	private Connection conn;

	public TurnoRepository(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void save(Turno turno) {
		if(turno==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
                    "insert into turnos (idDoctor, idPaciente, fecha, horario) values (?,?,?,?)",
                    PreparedStatement.RETURN_GENERATED_KEYS
			)){
			ps.setInt(1, turno.getIdDoctor());
			ps.setInt(2, turno.getIdPaciente());
			ps.setString(3, turno.getFecha());
			ps.setString(4, turno.getHorario());
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();
			if(rs.next())
				turno.setId(rs.getInt(1));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void remove(Turno turno) {
		if(turno==null) return;
		try (PreparedStatement ps = conn.prepareStatement("delete from turnos where id=?"	
			)){
			ps.setInt(1, turno.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void update(Turno turno) {
		if(turno==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
			"update turnos set idDoctor=?,idPaciente=?,fecha=?,horario=? where id=?"	
			)){
			ps.setInt(1, turno.getIdDoctor());
			ps.setInt(2, turno.getIdPaciente());
			ps.setString(3, turno.getFecha());
			ps.setString(4, turno.getHorario());
                        ps.setInt(5, turno.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Turno> getAll() {
		List<Turno>list=new ArrayList();
		//creamos un objeto de resultSet que va ser igual a estar conectado con una declaracion que ejecute una consulta ("la consulta debe ser escrita en codigo sql")
		try (ResultSet rs=conn.createStatement().executeQuery("select * from doctores")){
			while(rs.next()){
				list.add(new Turno(
						rs.getInt("id"),
						rs.getInt("idDoctor"),
						rs.getInt("idPaciente"),
						rs.getString("fecha"),
						rs.getString("horario")
				));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;	
	}
}