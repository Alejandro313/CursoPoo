package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.sanatorio.estrella.entities.Paciente;
import ar.org.sanatorio.estrella.repositories.interfaces.I_PacienteRepository;

public class PacienteRepository implements I_PacienteRepository{

	private Connection conn;

	public PacienteRepository(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void save(Paciente paciente) {
		if(paciente==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
				"insert into pacientes (nombre, apellido, edad, dni, obra_social) values (?,?,?,?,?)",
				PreparedStatement.RETURN_GENERATED_KEYS
			)){
			ps.setString(1, paciente.getNombre());
			ps.setString(2, paciente.getApellido());
			ps.setInt(3, paciente.getEdad());
			ps.setInt(4, paciente.getDni());
			ps.setString(5, paciente.getObra_social());
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();
			if(rs.next())
				paciente.setId(1);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void remove(Paciente paciente) {
		if(paciente==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
			"delete from pacientes where id=?"	
			)){
			ps.setInt(1, paciente.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void update(Paciente paciente) {
		if(paciente==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
			"update pacientes set nombre=?, apellido=?, edad=?, dni=?, obra_social=? where id=?"
			)){
			ps.setString(1, paciente.getNombre());
			ps.setString(2, paciente.getApellido());
			ps.setInt(3, paciente.getEdad());
			ps.setInt(4, paciente.getDni());
			ps.setString(5, paciente.getObra_social());
			ps.setInt(6, paciente.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Paciente> getAll() {
		List<Paciente>list=new ArrayList();
		try (ResultSet rs = conn.createStatement().executeQuery("select * from pacientes")){
			while(rs.next()) {
				list.add(new Paciente(
						rs.getInt("id"),
						rs.getString("nombre"),
						rs.getString("apellido"),
						rs.getInt("edad"),
						rs.getInt("dni"),
						rs.getString("obra_social")
						));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
}
