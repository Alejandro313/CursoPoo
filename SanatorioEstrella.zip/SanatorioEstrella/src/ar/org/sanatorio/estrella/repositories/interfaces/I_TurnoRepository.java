package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Turno;

public interface I_TurnoRepository {

	void save(Turno turno);
	void remove(Turno turno);
	void update(Turno turno);
	List<Turno>getAll();
	
	default Turno getById(int id){
		return getAll()
                    .stream()
                    .filter(t->t.getId()==id)
                    .findFirst()
                    .orElse(new Turno());
	}
	
	default Turno getByIdDoctor(int idDoctor){
		return getAll()
                    .stream()
                    .filter(t->t.getIdDoctor()==idDoctor)
                    .findFirst()
                    .orElse(new Turno());
	
	}
	
	default Turno getByIdPaciente(int idPaciente){
		return getAll()
				.stream()
                                .filter(t->t.getIdPaciente()==idPaciente)
                                .findFirst()
                                .orElse(new Turno());
	}
	
	default List<Turno> getLikeFecha(String fecha){
		if(fecha==null) new ArrayList();
		return getAll()
				.stream()
				.filter(t->t.getFecha().contains(fecha))
				.collect(Collectors.toList());
	}
	
	default List<Turno> getLikeHorario(String horario){
		if(horario==null) new ArrayList();
		return getAll()
				.stream()
				.filter(t->t.getHorario().contains(horario))
				.collect(Collectors.toList());
	}
}
