package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Turno_;

public interface I_TurnoRepository {

	void save(Turno_ turno);
	void remove(Turno_ turno);
	void update(Turno_ turno);
	List<Turno_>getAll();
	
	default List<Turno_> getLikeById(int id){
		return getAll()
				.stream()
				.filter(t->t.getId()==id)
				.collect(Collectors.toList());
	}
	
	default List<Turno_> getLikeByIdDoctor(int idDoctor){
		return getAll()
				.stream()
				.filter(t->t.getIdDoctor()==idDoctor)
				.collect(Collectors.toList());
	}
	
	default List<Turno_> getLikeByIdPaciente(int idPaciente){
		return getAll()
				.stream()
				.filter(t->t.getIdPaciente()==idPaciente)
				.collect(Collectors.toList());
	}
	
	default List<Turno_> getLikeFecha(String fecha){
		if(fecha==null) new ArrayList();
		return getAll()
				.stream()
				.filter(t->t.getFecha().contains(fecha))
				.collect(Collectors.toList());
	}
	
	default List<Turno_> getLikeHorario(String horario){
		if(horario==null) new ArrayList();
		return getAll()
				.stream()
				.filter(t->t.getHorario().contains(horario))
				.collect(Collectors.toList());
	}
}
