package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import ar.org.sanatorio.estrella.entities.Doctor_;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;

public class DoctorRepository implements I_DoctorRepository{
	
	private Connection conn;
	
	public DoctorRepository(Connection conn) { 
		this.conn = conn;
	}

	@Override
	public void save(Doctor_ doctor) {
		if(doctor==null) return;
		try (PreparedStatement ps=conn.prepareStatement(
				"Insert into curso: (nombre,apellido,dia,turno,idEspecialidad) values (?,?,?,?,?)",
				PreparedStatement.RETURN_GENERATED_KEYS
		)) {
			ps.setString(1, doctor.getNombre());
			ps.setString(2, doctor.getApellido());
			ps.setString(3, doctor.getDia()+"");
			ps.setString(4, doctor.getTurno()+"");
			ps.setInt(5, doctor.getIdEspecialidad());
			ps.execute();
			ResultSet rs=ps.getGeneratedKeys();
			if(rs.next())
				doctor.setId(rs.getInt(1));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void remove(Doctor_ doctor) {
		if(doctor == null) return;
	}

	@Override
	public void update(Doctor_ doctor) {
		if(doctor == null) return;
	}

	@Override
	public List<Doctor_> getAll() {
		List<Doctor_>list=new ArrayList();
		try (ResultSet rs=conn.createStatement().executeQuery("select * from doctores")){
			// devuelve un booleano siempre que exista un nuevo registro, recorrer� el apuntador.
			while(rs.next()) {
				list.add(new Doctor_(
						rs.getInt("id"),
						rs.getString("nombre"),
						rs.getString("apellido"),
						Dia.valueOf(rs.getString("dia")),
						Turno.valueOf(rs.getString("turno")),
						rs.getInt("idEspecialidad")
				));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

}
