package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;

public class DoctorRepository implements I_DoctorRepository{

	private Connection conn;
	
	public DoctorRepository(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void save(Doctor doctor) {
		if(doctor==null) return;
		try (PreparedStatement ps=conn.prepareStatement(
				"Insert into doctores (nombre,apellido,dia,turno,idEspecialidad) values (?,?,?,?,?)",
				PreparedStatement.RETURN_GENERATED_KEYS
		)) {
			ps.setString(1, doctor.getNombre());
			ps.setString(2, doctor.getApellido());
			ps.setString(3, doctor.getDia()+"");
			ps.setString(4, doctor.getTurno()+"");
			ps.setInt(5, doctor.getIdEspecialidad());
			ps.execute();
			ResultSet rs=ps.getGeneratedKeys();
			if(rs.next())
				doctor.setId(rs.getInt(1));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void remove(Doctor doctor) {
		if(doctor == null) return;
		try (PreparedStatement ps=conn.prepareStatement("delete from doctores where id=?"
		)){
			ps.setInt(1, doctor.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void update(Doctor doctor) {
		if(doctor == null) return;
		try (PreparedStatement ps=conn.prepareStatement(
			"update doctores set nombre=?, apellido=?, dia=?, turno=?, idEspecialidad=? where id=?"
		)){
			ps.setString(1,doctor.getNombre());
			ps.setString(2,doctor.getApellido());
			ps.setString(3,doctor.getDia()+"");
			ps.setString(4,doctor.getTurno()+"");
			ps.setInt(5,doctor.getIdEspecialidad());
			ps.setInt(6, doctor.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Doctor> getAll() {
		List<Doctor>list=new ArrayList();
		//creamos un objeto de resultSet que va ser igual a estar conectado con una declaracion que ejecute una consulta("la consulta debe ser escrita en codigo sql")
		try (ResultSet rs=conn.createStatement().executeQuery("select * from doctores")){
			while(rs.next()) {
				list.add(new Doctor(
						rs.getInt("id"),
						rs.getString("nombre"),
						rs.getString("apellido"),
						Dia.valueOf(rs.getString("dia")),
						Turno.valueOf(rs.getString("turno")),
						rs.getInt("idEspecialidad")
				));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
}
