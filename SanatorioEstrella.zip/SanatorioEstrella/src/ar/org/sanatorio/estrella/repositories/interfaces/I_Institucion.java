package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Institucion_;

public interface I_Institucion {

	void save(Institucion_ institucion);
	void remove(Institucion_ institucion);
	void update(Institucion_ institucion);
	List<Institucion_>getAll();
	
	default List <Institucion_> getById(int id) {
		return getAll()
				.stream()
                .filter(i->i.getId()==id)
                .collect(Collectors.toList());
	}
	
	default List <Institucion_> getLikeNombre (String nombre){
		if(nombre==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(i->i.getNombre().toLowerCase().contains(nombre.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List <Institucion_> getLikeCuit(String cuit){
		if(cuit==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(i->i.getCuit().contains(cuit))
				.collect(Collectors.toList());
	}
	
	default List <Institucion_> getLikeTelefono(int telefono){
		
		return getAll()
				.stream()
				.filter(i->i.getTelefono()==telefono)
				.collect(Collectors.toList());
	}
	
	default List <Institucion_> getLikeDireccion(String direccion){
		if(direccion==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(i->i.getDireccion().toLowerCase().contains(direccion.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List <Institucion_> getLikeHorario(String horario){
		if(horario==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(i->i.getHorario().contains(horario))
				.collect(Collectors.toList());
	}
}
