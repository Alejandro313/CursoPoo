package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Institucion;

public interface I_InstitucionRepository {

	void save(Institucion institucion);
	void remove(Institucion institucion);
	void update(Institucion institucion);
	List<Institucion>getAll();
	
	default List <Institucion> getById(int id) {
		return getAll()
				.stream()
                .filter(i->i.getId()==id)
                .collect(Collectors.toList());
	}
	
	default List <Institucion> getLikeNombre (String nombre){
		if(nombre==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(i->i.getNombre().toLowerCase().contains(nombre.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List <Institucion> getLikeCuit(String cuit){
		if(cuit==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(i->i.getCuit().contains(cuit))
				.collect(Collectors.toList());
	}
	
	default List <Institucion> getLikeTelefono(int telefono){
		
		return getAll()
				.stream()
				.filter(i->i.getTelefono()==telefono)
				.collect(Collectors.toList());
	}
	
	default List <Institucion> getLikeDireccion(String direccion){
		if(direccion==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(i->i.getDireccion().toLowerCase().contains(direccion.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List <Institucion> getLikeHorario(String horario){
		if(horario==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(i->i.getHorario().contains(horario))
				.collect(Collectors.toList());
	}
}
