package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Paciente;

public interface I_PacienteRepository {
    
	void save (Paciente paciente);
	void remove (Paciente paciente);
	void update (Paciente paciente);
	List<Paciente>getAll();
	
	default Paciente getById(int id){
        return getAll()
                .stream()
                .filter(p->p.getId()==id)
                .findFirst()
                .orElse(new Paciente());
    }
	
	default List <Paciente> getLikeNombre(String nombre){
		if(nombre==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase()))
				.collect(Collectors.toList());
	}
		
	default List <Paciente> getLikeApellido(String apellido){
		if(apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
		
	default List <Paciente> getLikeNombreAndApellido(String nombre, String apellido){
		if(nombre==null || apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List<Paciente>getByEdad(int edad){
        return getAll()
                .stream()
                .filter(p->p.getEdad()==edad)
                .collect(Collectors.toList());
    }
	
	default List <Paciente> getLikeNombreApellidoAndEdad(String nombre, String apellido, int edad){
		if(nombre==null || apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& p.getApellido().toLowerCase().contains(apellido.toLowerCase())
						&& p.getEdad()==edad)
				.collect(Collectors.toList());
	}
}