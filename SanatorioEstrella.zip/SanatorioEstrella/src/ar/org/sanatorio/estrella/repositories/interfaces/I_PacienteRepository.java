package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Paciente_;

public interface I_PacienteRepository {
    
	void save (Paciente_ paciente);
	void remove (Paciente_ paciente);
	void update (Paciente_ paciente);
	List<Paciente_>getAll();
	
	default Paciente_ getById(int id){
        return getAll()
                .stream()
                .filter(p->p.getId()==id)
                .findFirst()
                .orElse(new Paciente_());
    }
	
	default List <Paciente_> getLikeNombre(String nombre){
		if(nombre==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase()))
				.collect(Collectors.toList());
	}
		
	default List <Paciente_> getLikeApellido(String apellido){
		if(apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
		
	default List <Paciente_> getLikeNombreAndApellido(String nombre, String apellido){
		if(nombre==null || apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default List<Paciente_>getByEdad(int edad){
        return getAll()
                .stream()
                .filter(p->p.getEdad()==edad)
                .collect(Collectors.toList());
    }
	
	default List <Paciente_> getLikeNombreApellidoAndEdad(String nombre, String apellido, int edad){
		if(nombre==null || apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& p.getApellido().toLowerCase().contains(apellido.toLowerCase())
						&& p.getEdad()==edad)
				.collect(Collectors.toList());
	}
}