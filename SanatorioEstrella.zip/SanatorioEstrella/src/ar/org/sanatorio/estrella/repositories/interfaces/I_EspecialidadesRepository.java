package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Especialidad_;
import ar.org.sanatorio.estrella.enums.Especialidad;

public interface I_EspecialidadesRepository {
	
	void save(Especialidad_ especialidad);
	void remove(Especialidad_ especialidad);
	void update(Especialidad_ especialidad);
	List<Especialidad_>getAll();
	
	default Especialidad_ getById(int id){ 
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Especialidad_());
    }
	
	default Especialidad_ getById_instituciones(int id_institucion){ 
        return getAll()
                .stream()
                .filter(c->c.getId()==id_institucion)
                .findFirst()
                .orElse(new Especialidad_());
    }
	
	default List<Especialidad_>getLikeEspecialidad(Especialidad especialidad){
		if(especialidad==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(e->e.getEspecialidad()==especialidad)
				.collect(Collectors.toList());
	}
}