package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Especialidades;
import ar.org.sanatorio.estrella.enums.Especialidad;

public interface I_EspecialidadesRepository {

	void save(Especialidades especialidad);
	void remove(Especialidades especialidad);
	void update(Especialidades especialidad);
	List<Especialidades>getAll();
	
	
	default Especialidades getById(int id){ 
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Especialidades());
    }
	
	default Especialidades getById_instituciones(int id_institucion){ 
        return getAll()
                .stream()
                .filter(c->c.getId()==id_institucion)
                .findFirst()
                .orElse(new Especialidades());
    }
	
	default List<Especialidades>getLikeEspecialidad(Especialidad especialidad){
		if(especialidad==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(e->e.getEspecialidad()==especialidad)
				.collect(Collectors.toList());
	}
}
