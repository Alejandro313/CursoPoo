package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.sanatorio.estrella.entities.Institucion;
import ar.org.sanatorio.estrella.repositories.interfaces.I_InstitucionRepository;

public class InstitucionRepository implements I_InstitucionRepository {

	private Connection conn;

	public InstitucionRepository(Connection conn) {
		this.conn = conn;
	}

	@Override
	public void save(Institucion institucion) {
		if(institucion == null);
		try (PreparedStatement ps=conn.prepareStatement(
			"insert into institucion (nombre, cuit, telefono, direccion, horario) values (?,?,?,?,?)",
			PreparedStatement.RETURN_GENERATED_KEYS
		)){
			ps.setString(1, institucion.getNombre());
			ps.setString(2, institucion.getCuit());
			ps.setInt(3, institucion.getTelefono());
			ps.setString(4, institucion.getDireccion());
			ps.setString(5, institucion.getHorario());
			ps.execute();
			ResultSet rs=ps.getGeneratedKeys();
			if(rs.next())
				institucion.setId(rs.getInt(1));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void remove(Institucion institucion) {
		if(institucion==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
			"delete from institucion where id=?"	
		)){
			ps.setInt(1, institucion.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void update(Institucion institucion) {
		if(institucion==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
			"update institucion set nombre=?, cuit=?, telefono=?, direccion=?, horario=? where id=?"
		)){
			ps.setString(1, institucion.getNombre());
			ps.setString(2, institucion.getCuit());
			ps.setInt(3, institucion.getTelefono());
			ps.setString(4, institucion.getDireccion());
			ps.setString(5, institucion.getHorario());
			ps.setInt(6, institucion.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Institucion> getAll() {
		List<Institucion> list = new ArrayList();
		try (ResultSet rs = conn.createStatement().executeQuery("select * from institucion")){
			while(rs.next()) {
				list.add(new Institucion(
						rs.getInt("id"),
						rs.getString("nombre"),
						rs.getString("cuit"),
						rs.getInt("telefono"),
						rs.getString("direccion"),
						rs.getString("horario")
						));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
}
