package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;

public interface I_EspecialidadRepository {

	void save(Especialidad especialidad);
	void remove(Especialidad especialidad);
	void update(Especialidad especialidad);
	List<Especialidad>getAll();
	
	default Especialidad getById(int id){
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Especialidad());
    }
	
	default Especialidad getById_instituciones(int id_institucion){
        return getAll()
                .stream()
                .filter(c->c.getId()==id_institucion)
                .findFirst()
                .orElse(new Especialidad());
    }
	
	default List<Especialidad>getLikeEspecialidad(TipoEspecialidad especialidad){
		if(especialidad==null) return new ArrayList<>();
		return getAll()
				.stream()
				.filter(e->e.getEspecialidad()==especialidad)
				.collect(Collectors.toList());
	}

}
