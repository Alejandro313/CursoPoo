package ar.org.sanatorio.estrella.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;

public class EspecialidadRepository implements I_EspecialidadRepository{

	private Connection conn;
	
	public EspecialidadRepository(Connection conn) {
		this.conn=conn;
	}
	
	@Override
	public void save(Especialidad especialidad) {
		if(especialidad==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
				"insert into especialidades (id_institucion, tipoEspecialidad) values (?,?)",
				PreparedStatement.RETURN_GENERATED_KEYS
		)) {
			ps.setInt(1, especialidad.getId_institucion());
			ps.setString(2, especialidad.getEspecialidad()+"");
			ps.execute();
			ResultSet rs=ps.getGeneratedKeys();
			if(rs.next())
				especialidad.setId(rs.getInt(1));
		} catch (Exception e) {
		System.out.println(e);	
		}
	}

	@Override
	public void remove(Especialidad especialidad) {
		if(especialidad==null) return;
		try (PreparedStatement ps=conn.prepareStatement(
				"delete from especialidades where id=?"
		)){
			ps.setInt(1, especialidad.getId());
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void update(Especialidad especialidad) {
		if(especialidad==null) return;
		try (PreparedStatement ps = conn.prepareStatement(
				"update especialidades set id_institucion=?, tipoEspecialidad=? where id=?"
		)){
			ps.setInt(1, especialidad.getId_institucion());
			ps.setString(2, especialidad.getEspecialidad()+"");
			ps.execute();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Especialidad> getAll() {
		List<Especialidad> list = new ArrayList();
		try (ResultSet rs=conn.createStatement().executeQuery("select * from especialidades")){
			while(rs.next()) {
				list.add(new Especialidad(
						rs.getInt("id"),
						rs.getInt("id_institucion"),
						TipoEspecialidad.valueOf(rs.getString("tipoEspecialidad"))
						)
				);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
}
