package ar.org.sanatorio.estrella.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.Turno;

public interface I_DoctorRepository {
    
	void save(Doctor doctor);
	void remove(Doctor doctor);
	void update(Doctor doctor);
	List<Doctor>getAll();
	
	//Mostrar nombres
	default List <Doctor> getLikeNombre(String nombre){
		if(nombre==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(d->d.getNombre().toLowerCase().contains(nombre.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	//Mostrar apellidos
	default List <Doctor> getLikeApellido(String apellido){
		if(apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(d->d.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	//Mostrar nombres y apellidos
	default List <Doctor> getLikeNombreAndApellido(String nombre, String apellido){
		if(nombre==null || apellido==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(d->d.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& d.getApellido().toLowerCase().contains(apellido.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	//mostrar dia
	default List<Doctor>getByDia(Dia dia){
        if(dia==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getDia()==dia)
                .collect(Collectors.toList());
    }
	
	//turno
	default List<Doctor>getByTurno(Turno turno){
        if(turno==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(d->d.getTurno()==turno)
                .collect(Collectors.toList());
    }
	
	//Mostrar nombre, apellido, dia y turno 
	default List <Doctor> getLikeidPacienteNombreApellidoDiaAndTurno(String nombre, String apellido, Dia dia, Turno turno){
		if (nombre==null || apellido==null || dia==null || turno==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(d->d.getNombre().toLowerCase().contains(nombre.toLowerCase())
						&& d.getApellido().toLowerCase().contains(apellido.toLowerCase())
						&& d.getDia()==dia && d.getTurno()==turno)
				.collect(Collectors.toList());
	}
}