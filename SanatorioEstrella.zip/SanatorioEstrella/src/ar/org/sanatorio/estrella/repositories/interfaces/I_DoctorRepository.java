package ar.org.sanatorio.estrella.repositories.interfaces;

public interface I_DoctorRepository {
    
}
