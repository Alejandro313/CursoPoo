package ar.org.sanatorio.estrella.gui.ventanas;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.entities.Institucion;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_InstitucionRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.InstitucionRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;
import ar.org.sanatorio.estrella.utils.swing.Validator;
import java.util.Comparator;

public class FormEspecialidades extends javax.swing.JInternalFrame {
I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
I_InstitucionRepository insti=new InstitucionRepository(Connector.getConnection());

private Institucion institucion;
private Especialidad especialidad;
    public FormEspecialidades() {
        super(
                "Lista de especialidades",              //title 
               false,           //resizable
                true,           //closeable
                false,           //maximizable
                true            //iconable
        );
        initComponents();
        CargarElementos();
    }

     private void CargarElementos() {
        
         
       new Table().cargar(tblEspecialidades, espe.getAll());
       insti.getAll().forEach(i->cmbInstitucion.addItem(i.getNombre()));
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cmbInstitucion = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEspecialidades = new javax.swing.JTable();
        txtEspecialidad = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        txtIdInsti = new javax.swing.JTextField();

        jLabel1.setText("Especialidad");

        jLabel2.setText("Institucion");

        cmbInstitucion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbInstitucionActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(tblEspecialidades);

        btnGuardar.setText("Agregar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtIdInsti.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 252, Short.MAX_VALUE)
                                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(cmbInstitucion, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtIdInsti, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(cmbInstitucion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIdInsti, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbInstitucionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbInstitucionActionPerformed
        // Evento intitucion
        int idInsti=1;
        if(cmbInstitucion.getItemAt(cmbInstitucion.getSelectedIndex()).equals("Sanatorio Estrella")){
            txtIdInsti.setText(idInsti+"");
        }
    }//GEN-LAST:event_cmbInstitucionActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // Evento guardar
        if(!validar()) return;
        Especialidad especialidad = new Especialidad(
                Integer.parseInt(txtIdInsti.getText()), 
                TipoEspecialidad.valueOf(txtEspecialidad.getName().toUpperCase()));
        espe.save(especialidad);
        
        CargarElementos();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void Limpiar() {
        txtEspecialidad.setText("");
    }
    
    private boolean validar(){
        if(!new Validator(txtEspecialidad).length(4, 25)) return false;
        return true;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<String> cmbInstitucion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblEspecialidades;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtIdInsti;
    // End of variables declaration//GEN-END:variables
}
