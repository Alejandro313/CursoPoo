package ar.org.sanatorio.estrella.gui.ventanas;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.entities.Paciente;
import ar.org.sanatorio.estrella.entities.Turno;
import ar.org.sanatorio.estrella.gui.ventanas.subs.ListarDoctores;
import ar.org.sanatorio.estrella.gui.ventanas.subs.ListarPacientes;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_PacienteRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_TurnoRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.PacienteRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.TurnoRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;
import ar.org.sanatorio.estrella.utils.swing.Validator;
import java.util.List;
import javax.swing.JOptionPane;

public class FormTurnos extends javax.swing.JInternalFrame {
    private I_TurnoRepository tur = new TurnoRepository(Connector.getConnection());
    private I_DoctorRepository dr = new DoctorRepository(Connector.getConnection());
    private I_PacienteRepository paci = new PacienteRepository(Connector.getConnection());
    
    private Doctor doctor;
    private Paciente paciente;
    public FormTurnos() {
        super(
                "Formulario de turnos",              //title 
               false,           //resizable
                true,           //closeable
                false,           //maximizable
                true            //iconable
        );
        initComponents();
        CargarElementos();
    }

     private void CargarElementos() {
        new Table().cargar(tblTurnos, tur.getAll());
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTurnos = new javax.swing.JTable();
        btnMostrarDoctor = new javax.swing.JButton();
        btnMostrarPacientes = new javax.swing.JButton();

        jButton1.setText("jButton1");

        jScrollPane1.setViewportView(tblTurnos);

        btnMostrarDoctor.setText("Mostrar doctor");
        btnMostrarDoctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarDoctorActionPerformed(evt);
            }
        });

        btnMostrarPacientes.setText("Mostrar pacientes del turno");
        btnMostrarPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarPacientesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnMostrarPacientes, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnMostrarDoctor, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMostrarDoctor)
                    .addComponent(btnMostrarPacientes))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMostrarDoctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarDoctorActionPerformed
        // Evento mostrar doctores
        int fila=tblTurnos.getSelectedRow(); //selecciona la fila y lo guarda en fila
        if(fila==-1) return;
        int id=(int)tblTurnos.getValueAt(fila, 1);
        Doctor doctor = new Doctor();
        ListarDoctores ld = new ListarDoctores(doctor); //Listamos las especialidades
        this.getParent().add(ld); //lo agregamos al desktop en el contenedor padre
        ld.setVisible(true); //Lo hacemos visible
    }//GEN-LAST:event_btnMostrarDoctorActionPerformed

    private void btnMostrarPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarPacientesActionPerformed
        //Evento mostrar Pacientes
        int fila=tblTurnos.getSelectedRow(); //selecciona la fila y lo guarda en fila
        if(fila==-1) return;
        int id=(int)tblTurnos.getValueAt(fila, 2);
        Paciente paciente = paci.getById(id);
        ListarPacientes lp = new ListarPacientes(paciente); //Listamos las especialidades
        this.getParent().add(lp); //lo agregamos al desktop en el contenedor padre
        lp.setVisible(true); //Lo hacemos visible
    }//GEN-LAST:event_btnMostrarPacientesActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrarDoctor;
    private javax.swing.JButton btnMostrarPacientes;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblTurnos;
    // End of variables declaration//GEN-END:variables
}
