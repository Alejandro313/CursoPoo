package ar.org.sanatorio.estrella.gui;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;

public class IdEspecialidades extends javax.swing.JInternalFrame {
I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
 
    public IdEspecialidades() {
        super(
                "ID de especialidades",              //title 
               false,           //resizable
                true,           //closeable
                false,           //maximizable
                true            //iconable
        );
        initComponents();
        CargarElementos();
    }

    private void CargarElementos() {
        new Table().cargar(tblIdEspecialidad, espe.getAll());
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblIdEspecialidad = new javax.swing.JTable();

        jScrollPane1.setViewportView(tblIdEspecialidad);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 447, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblIdEspecialidad;
    // End of variables declaration//GEN-END:variables
}
