package ar.org.sanatorio.estrella.gui;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;

public class IdEspecialidades extends javax.swing.JInternalFrame {
I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());
 
    public IdEspecialidades() {
        super(
                "ID de especialidades",              //title 
               false,           //resizable
                true,           //closeable
                false,           //maximizable
                true            //iconable
        );
        initComponents();
        CargarElementos();
    }

    private void CargarElementos() {
        new Table().cargar(tblIdEspecialidad, espe.getAll());
        new Table().cargar(tblDoctores, dr.getAll());
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblIdEspecialidad = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDoctores = new javax.swing.JTable();

        jScrollPane1.setViewportView(tblIdEspecialidad);

        jScrollPane2.setViewportView(tblDoctores);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblDoctores;
    private javax.swing.JTable tblIdEspecialidad;
    // End of variables declaration//GEN-END:variables
}
