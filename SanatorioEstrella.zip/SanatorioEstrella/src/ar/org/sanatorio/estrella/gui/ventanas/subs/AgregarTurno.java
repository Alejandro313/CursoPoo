package ar.org.sanatorio.estrella.gui.ventanas.subs;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.entities.Paciente;
import ar.org.sanatorio.estrella.entities.Turno;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.TipoEspecialidad;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_PacienteRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_TurnoRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.PacienteRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.TurnoRepository;
import java.util.Comparator;
import java.util.List;


public class AgregarTurno extends javax.swing.JInternalFrame {
    I_TurnoRepository tur = new TurnoRepository(Connector.getConnection());
    I_PacienteRepository paci = new PacienteRepository(Connector.getConnection());
    I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
    I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());

    private Paciente paciente;
    private Turno turno;
    private Doctor doctor;
    private Especialidad especialidad;
    public AgregarTurno(Paciente paciente, Turno turno) {
         super(
                "Lista de especialidades",              //title 
               false,           //resizable
                true,           //closeable
                false,           //maximizable
                true            //iconable
        );
        initComponents();
        this.turno=turno;
        this.paciente=paciente;
        CargarElementos(paciente,turno);
    }

    private void CargarElementos(Paciente paciente, Turno turno){
       //No editables
        txtNombre.setEditable(false);
        txtApellido.setEditable(false);
        txtEdad.setEditable(false);
        txtDni.setEditable(false);
        txtObraSocial.setEditable(false);
        txtidPaciente.setEditable(false);
        
        //Cargar paciente
       txtNombre.setText(paciente.getNombre());
       txtApellido.setText(paciente.getApellido());
       txtEdad.setText(paciente.getEdad()+"");
       txtDni.setText(paciente.getDni()+"");
       txtObraSocial.setText(paciente.getObra_social());
       
       //Cargar turno
       List.of(TipoEspecialidad.values()).forEach(cmbEspecialidad::addItem);
       
               
               /* if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("ENDOCRINOLOGIA")){
               idEspe=espe.getAll()
               .stream()
               .filter(e-> e.getEspecialidad()==TipoEspecialidad.ENDOCRINOLOGIA)
               .max(Comparator.comparingInt(Especialidad::getId))
               .get()
               .getId();
               txtIdEspecialidad.setText(idEspe+"");  */    
               
        if(txtIdEspecialidad.getText().equals(doctor.getIdEspecialidad())){
                
        }       
       //dr.getAll().forEach(d->cmbDoctor.addItem(d.getNombre()+" "+d.getApellido()));
       txtidPaciente.setText(paciente.getId()+"");
       List.of(Dia.values()).forEach(cmbDias::addItem);
       
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        txtTurnos = new javax.swing.JTextField();
        txtHorario = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtidPaciente = new javax.swing.JTextField();
        lblInfo = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblApellido = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblDni = new javax.swing.JLabel();
        lblEdad = new javax.swing.JLabel();
        lblObraSocial = new javax.swing.JLabel();
        txtObraSocial = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtEdad = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        cmbEspecialidad = new javax.swing.JComboBox<>();
        txtIdEspecialidad = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtFecha1 = new javax.swing.JTextField();
        cmbDias = new javax.swing.JComboBox<>();

        jLabel2.setText("ID Paciente");

        jLabel1.setText("Especialidad");

        jLabel3.setText("Fecha");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtTurnos.setEditable(false);

        jLabel4.setText("Horario");

        jLabel5.setText("Nombre");

        jLabel6.setText("Apellido");

        jLabel7.setText("Edad");

        jLabel8.setText("DNI");

        jLabel9.setText("Obra social");

        cmbEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbEspecialidadActionPerformed(evt);
            }
        });

        txtIdEspecialidad.setEditable(false);

        jLabel11.setText("Dias disponibles");

        jLabel12.setText("Turno");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblEdad)
                    .addComponent(lblDni)
                    .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(249, 249, 249)
                        .addComponent(lblApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(lblObraSocial, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(6, 6, 6)
                                        .addComponent(txtObraSocial, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(12, 12, 12)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel5)
                                                        .addGap(7, 7, 7)
                                                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel6)
                                                        .addGap(7, 7, 7)
                                                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(14, 14, 14)
                                                .addComponent(jLabel7)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(20, 20, 20)
                                                .addComponent(jLabel8)
                                                .addGap(18, 18, 18)
                                                .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(36, 36, 36)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel12)
                                                .addComponent(jLabel11)
                                                .addComponent(jLabel3)
                                                .addComponent(jLabel4)))))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtidPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFecha1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(117, 117, 117)
                                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(cmbDias, javax.swing.GroupLayout.Alignment.LEADING, 0, 100, Short.MAX_VALUE)
                                        .addComponent(txtTurnos, javax.swing.GroupLayout.Alignment.LEADING))))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtIdEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblEdad)
                    .addComponent(lblDni))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblNombre)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel5))
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel6))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel7))
                            .addComponent(txtEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel8))
                            .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtObraSocial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel9))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblApellido)
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cmbEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtIdEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtidPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(cmbDias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addComponent(lblObraSocial)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTurnos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addGap(4, 4, 4)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtFecha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(btnGuardar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
          Turno turno = new Turno(
                  Integer.parseInt(txtIdEspecialidad.getText()), 
                  Integer.parseInt(txtidPaciente.getText()), 
                  txtTurnos.getText(), 
                  txtHorario.getText());

        tur.save(turno);
        lblInfo.setText("Se Guardo un nuevo Turno al paciente "+paciente.getId());

        CargarElementos(paciente,turno);
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void cmbEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbEspecialidadActionPerformed
        // TODO add your handling code here:
        int idDoc;
        if(cmbEspecialidad.getItemAt(cmbEspecial idad.getSelectedIndex()).name().equals("GASTROENTEROLOGIA")){
            idDoc=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.GASTROENTEROLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idDoc+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("CARDIOLOGIA")){
            idDoc=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.CARDIOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("PEDIATRIA")){
            idDoc=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.PEDIATRIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("NEUMOLOGIA")){
            idDoc=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.NEUMOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("ODONTOLOGIA")){
            idEspe=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.ODONTOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("OFTALMOLOGIA")){
            idEspe=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.OFTALMOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("OTORRINOLARINGOLOGIA")){
            idEspe=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.OTORRINOLARINGOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }else if(cmbEspecialidad.getItemAt(cmbEspecialidad.getSelectedIndex()).name().equals("ENDOCRINOLOGIA")){
            idEspe=espe.getAll()
            .stream()
            .filter(e-> e.getEspecialidad()==TipoEspecialidad.ENDOCRINOLOGIA)
            .max(Comparator.comparingInt(Especialidad::getId))
            .get()
            .getId();
            txtIdEspecialidad.setText(idEspe+"");
        }
    }//GEN-LAST:event_cmbEspecialidadActionPerformed
    
    private void Limpiar() {
        txtIdEspecialidad.setText("");
        txtidPaciente.setText("");
        txtTurnos.setText("");
        txtHorario.setText("");
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<Dia> cmbDias;
    private javax.swing.JComboBox<TipoEspecialidad> cmbEspecialidad;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblDni;
    private javax.swing.JLabel lblEdad;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblObraSocial;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtFecha1;
    private javax.swing.JTextField txtHorario;
    private javax.swing.JTextField txtIdEspecialidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtObraSocial;
    private javax.swing.JTextField txtTurnos;
    private javax.swing.JTextField txtidPaciente;
    // End of variables declaration//GEN-END:variables
}
