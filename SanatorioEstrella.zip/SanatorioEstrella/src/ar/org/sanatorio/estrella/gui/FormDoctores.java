
package ar.org.sanatorio.estrella.gui;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Doctor;
import ar.org.sanatorio.estrella.entities.Especialidad;
import ar.org.sanatorio.estrella.enums.Dia;
import ar.org.sanatorio.estrella.enums.DiaTurno;
import ar.org.sanatorio.estrella.repositories.interfaces.I_DoctorRepository;
import ar.org.sanatorio.estrella.repositories.interfaces.I_EspecialidadRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.DoctorRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.EspecialidadRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;
import ar.org.sanatorio.estrella.utils.swing.Validator;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;

public class FormDoctores extends javax.swing.JInternalFrame {
    
    I_EspecialidadRepository espe=new EspecialidadRepository(Connector.getConnection());
    I_DoctorRepository dr=new DoctorRepository(Connector.getConnection());
    
    public FormDoctores() {
        super(
                "Formulario de doctores",//title 
               false,             //resizable
                true,            //closeable
                false,          //maximizable
                true           //iconable
        );
        initComponents();
        
        CargarElementos();
    }

    private void CargarElementos() {
        //Cargar cmbDia
        cmbDia.removeAllItems();
        List.of(Dia.values()).forEach(cmbDia::addItem);
        //Cargar cmbDiaTurno
        cmbTurno.removeAllItems();
        List.of(DiaTurno.values()).forEach(cmbTurno::addItem);
        //Cargar cmbEspecialidad
       // cmbEspecialidad.removeAllItems();
       //List.of(TipoEspecialidad.values()).forEach(cmbEspecialidad::addItem);
        
        //Cargamos la tabla
        new Table().cargar(tblDoctores, dr.getAll());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        lblInfo = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        cmbDia = new javax.swing.JComboBox<>();
        cmbTurno = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDoctores = new javax.swing.JTable();
        btnEliminar = new javax.swing.JButton();
        btnMostrarEspecialidad = new javax.swing.JButton();
        txtBuscarNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtBuscarApellido = new javax.swing.JTextField();
        lblInfoEspecialidad = new javax.swing.JLabel();
        btnModificar = new javax.swing.JButton();
        txtIdEspecialidad = new javax.swing.JTextField();
        btnIdEspecialidad = new javax.swing.JButton();

        jLabel1.setText("Nombre");

        jLabel2.setText("Apellido");

        jLabel3.setText("Dia");

        jLabel4.setText("Turno");

        jLabel5.setText("ID Especialidad");

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        tblDoctores.setAutoCreateRowSorter(true);
        tblDoctores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tblDoctores);

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnMostrarEspecialidad.setText("Mostrar Especialidad");
        btnMostrarEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarEspecialidadActionPerformed(evt);
            }
        });

        txtBuscarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarNombreActionPerformed(evt);
            }
        });

        jLabel6.setText("Buscar Nombre:");

        jLabel7.setText("Buscar Apellido");

        txtBuscarApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarApellidoActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnIdEspecialidad.setText("Mostrar ID");
        btnIdEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIdEspecialidadActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(42, 42, 42))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnMostrarEspecialidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cmbTurno, 0, 181, Short.MAX_VALUE)
                                    .addComponent(txtNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                    .addComponent(txtApellido, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                    .addComponent(cmbDia, 0, 181, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtIdEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnIdEspecialidad)))
                                .addGap(13, 13, 13)
                                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtBuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtBuscarApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(lblInfoEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(35, 35, 35)))))
                        .addGap(0, 29, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(cmbTurno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtIdEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnIdEspecialidad)
                    .addComponent(btnGuardar)
                    .addComponent(btnEliminar))
                .addGap(18, 18, 18)
                .addComponent(lblInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtBuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtBuscarApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnModificar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblInfoEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnMostrarEspecialidad)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //Guardar de especialidad
       if(!validar()) return;
       
       // Guardar de doctor 
       Doctor doctor=new Doctor(
               txtNombre.getText(), 
               txtApellido.getText(), 
               cmbDia.getItemAt(cmbDia.getSelectedIndex()), 
               cmbTurno.getItemAt(cmbTurno.getSelectedIndex()),
               Integer.parseInt(txtIdEspecialidad.getText())
             //cmbEspecialidad.getSelectedIndex()
        );
       
       dr.save(doctor);
       lblInfo.setText("Se Guardo un nuevo doctor con id "+doctor.getId());
       
       CargarElementos();
       Limpiar();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void Limpiar() {
        txtNombre.setText("");
        txtApellido.setText("");
        cmbDia.getSelectedIndex();
        cmbTurno.getSelectedIndex();
        txtIdEspecialidad.setText("");
    }
     
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Evento eliminar doctores
        int fila=tblDoctores.getSelectedRow(); //selecciona la fila y lo guarda en fila
        if(fila==-1) return;
        int id=(int)tblDoctores.getValueAt(fila, 0); //
        if(JOptionPane.showConfirmDialog(this, "Desea borrar el doctor id: "+id+"?")!=0) return;
        Doctor doctor=dr.getById(id);
        dr.remove(doctor);
        CargarElementos();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnMostrarEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarEspecialidadActionPerformed
        // Mostrar especialidad
        int fila=tblDoctores.getSelectedRow();
        if(fila==-1) return; 
        int id=(int)tblDoctores.getValueAt(fila, 0);
        int idEspecialidad=(int)tblDoctores.getValueAt(fila, 5);
        Doctor doctor=dr.getById(id);
        Especialidad especialidad=espe.getById(idEspecialidad);
        
        switch(idEspecialidad){
        case 1: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Gastroenterologia \n");
            break;
        case 2: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Cardiologia\n");
            break;
        case 3: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Pediatria\n");
            break;
        case 4: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Neumologia\n");
            break;
        case 5: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Odontologia\n");
            break;
        case 6: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Oftalmologia\n");
            break;
        case 7: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Otorrinolaringologia\n");
            break;
        case 8: lblInfoEspecialidad.setText("Doctor/a "+doctor.getNombre()+" "+
                doctor.getApellido()+" de Endocrinologia\n");
            break;
        }
    
        CargarElementos();
    }//GEN-LAST:event_btnMostrarEspecialidadActionPerformed

    private void txtBuscarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarNombreActionPerformed
        // Evento buscar nombre
        new Table<Doctor>().cargar(tblDoctores, dr.getLikeNombre(txtBuscarNombre.getText()));
    }//GEN-LAST:event_txtBuscarNombreActionPerformed

    private void txtBuscarApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarApellidoActionPerformed
        // Evento buscar apellido
        new Table<Doctor>().cargar(tblDoctores, dr.getLikeApellido(txtBuscarApellido.getText()));
    }//GEN-LAST:event_txtBuscarApellidoActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        int fila=tblDoctores.getSelectedRow(); //selecciona la fila y lo guarda en fila
        if(fila==-1) return;
        int id=(int)tblDoctores.getValueAt(fila, 0); //
        if(JOptionPane.showConfirmDialog(this, "Desea Modificar el: "+id+"?")!=0) return;
        Doctor doctor=dr.getById(id);
        ModificarDoctores md = new ModificarDoctores(doctor);
        this.getParent().add(md);
        md.setVisible(true);
        CargarElementos();
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnIdEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIdEspecialidadActionPerformed
        // Evento mostrar id especialidad
        IdEspecialidades ie = new IdEspecialidades();
        this.getParent().add(ie);
        ie.setVisible(true);
        CargarElementos();
    }//GEN-LAST:event_btnIdEspecialidadActionPerformed

    private boolean validar(){
        if(!new Validator(txtNombre).length(3, 20)) return false;
        if(!new Validator (txtApellido).length(3, 20)) return false;
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnIdEspecialidad;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnMostrarEspecialidad;
    private javax.swing.JComboBox<Dia> cmbDia;
    private javax.swing.JComboBox<DiaTurno> cmbTurno;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblInfoEspecialidad;
    private javax.swing.JTable tblDoctores;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscarApellido;
    private javax.swing.JTextField txtBuscarNombre;
    private javax.swing.JTextField txtIdEspecialidad;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
