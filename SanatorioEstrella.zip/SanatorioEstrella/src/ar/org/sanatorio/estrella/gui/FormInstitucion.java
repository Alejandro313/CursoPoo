
package ar.org.sanatorio.estrella.gui;

import ar.org.sanatorio.estrella.connectors.Connector;
import ar.org.sanatorio.estrella.entities.Institucion;
import ar.org.sanatorio.estrella.repositories.interfaces.I_InstitucionRepository;
import ar.org.sanatorio.estrella.repositories.jdbc.InstitucionRepository;
import ar.org.sanatorio.estrella.utils.swing.Table;


public class FormInstitucion extends javax.swing.JInternalFrame {
    I_InstitucionRepository insti = new InstitucionRepository(Connector.getConnection());
    public FormInstitucion() {
        super(
                "Formulario de institucion",              //title 
                true,           //resizable
                true,           //closeable
                true,           //maximizable
                true            //iconable
        );
        initComponents();
        CargarComponentes();
    }
     private void CargarComponentes() {
         new Table().cargar(tblInstitucion, insti.getAll());
    }
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblInstitucion = new javax.swing.JTable();

        jScrollPane1.setViewportView(tblInstitucion);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 642, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblInstitucion;
    // End of variables declaration//GEN-END:variables

}
