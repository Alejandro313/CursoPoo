/*
Remote Host: freedb.tech
Port: 3306
Database Name: freedbtech_sanatorio
Username: freedbtech_sanatorio
Password: estrella
*/

drop database if exists Sanatorio;
create database Sanatorio;
use Sanatorio;
drop table if exists doctor;
drop table if exists paciente;
show tables;

create table doctor(
id int auto_increment primary key,
especialidad enum ('Cardiologia','Gastroenterologia','Endocrinologia','Neumologia','Odontologia','Otorrinolaringologia','Oftalmologia','Pediatria'),
nombre varchar(25) not null,
apellido varchar(25) not null,
dia enum ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'),
turno enum ('MAÑANA','TARDE')
);

create table paciente(
id int auto_increment primary key,
nombre varchar(25) not null,
apellido varchar(25) not null,
turnoID int, 
dia_y_horario datetime
);

alter table paciente
    add constraint FK_Paciente_IdPaciente
    foreign key(turnoID)
    references doctor(id);