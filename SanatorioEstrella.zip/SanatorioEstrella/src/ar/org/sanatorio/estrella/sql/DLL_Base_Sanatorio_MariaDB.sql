/*
Remote Host: freedb.tech
Port: 3306
Database Name: freedbtech_sanatorio
Username: freedbtech_sanatorio
Password: estrella
*/

drop database if exists sanatorio;
create database sanatorio;
use sanatorio;
drop table if exists institucion;
drop table if exists especialidades;
drop table if exists turnos;
drop table if exists doctores;
drop table if exists pacientes;
show tables;

create table institucion(
	id int auto_increment primary key, -- FK con especialidades
	nombre varchar (30) not null,
	cuit varchar (15) not null,
	telefono int,
	direccion varchar (50) not null,
	horarios varchar (10) not null
);

create table doctores(
	id int auto_increment primary key, -- FK turnos
	nombre varchar(25) not null,
	apellido varchar(25) not null,
	dia enum ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'),
	turno enum ('MAÑANA','TARDE'),
	idEspecialidad int not null
);

create table especialidades(
	id int auto_increment primary key,
    id_institucion int,
	especialidad enum ('CARDIOLOGIA','GASTROENTEROLOGIA','ENDOCRINOLOGIA','NEUMOLOGIA','ODONTOLOGIA','OTORRINOLARINGOLOGIA','OFTALMOLOGIA','PEDIATRIA')
);

create table turnos(
    id int auto_increment primary key,
    idDoctor int, -- KF doctor (id)
    idPaciente int, -- KF pacientes (id)
    fecha date,
    horario enum('07:00','08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00')
);

create table pacientes(
	id int auto_increment primary key,
	nombre varchar(25) not null,
	apellido varchar(25) not null,
	edad int,
	dni int,
	obra_social varchar (30) not null
);

alter table turnos
    add constraint FK_Doctor_IdDoctores
    foreign key(idDoctor)
    references doctores(id);

alter table turnos
    add constraint FK_Paciente_IdPacientes
    foreign key(idPaciente)
    references pacientes(id);
    
alter table especialidades
    add constraint FK_institucion_Id
    foreign key(id_institucion)
    references institucion(id);
    
alter table doctores
    add constraint FK_Especialidades_Id
    foreign key(idEspecialidad)
    references especialidades(id);