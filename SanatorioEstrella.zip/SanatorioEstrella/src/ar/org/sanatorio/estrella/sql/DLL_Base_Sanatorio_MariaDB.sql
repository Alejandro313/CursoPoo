/*
Remote Host: freedb.tech
Port: 3306
Database Name: freedbtech_sanatorio
Username: freedbtech_sanatorio
Password: estrella
*/

drop database if exists sanatorio;
create database sanatorio;
use sanatorio;
drop table if exists doctor;
drop table if exists paciente;
show tables;

create table institucion(
nombre varchar (10) not null,
cuit varchar (15) not null,
telefono int,
direccion varchar,
);

create table doctores(
id int auto_increment primary key,
nombre varchar(25) not null,
apellido varchar(25) not null,
dia enum ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'),
turno enum ('MAÑANA','TARDE')
);

create table especialidades(
id int, -- FK doctor
especialidad enum ('CARDIOLOGIA','GASTROENTEROLOGIA','ENDOCRINOLOGIA','NEUMOLOGIA','ODONTOLOGIA','OTORRINOLARINGOLOGIA','OFTALMOLOGIA','PEDIATRIA'),
);

crete table turnos(
    id int auto_increment primary key,
    idDoctor int, -- KF doctor
    idPaciente int, -- KF pacientes
    fecha date,
    horario enum('08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00')
);

create table pacientes(
id int auto_increment primary key,
nombre varchar(25) not null,
apellido varchar(25) not null,
edad int,
dni int,
obra_social varchar (30) not null,
);

alter table turnos
    add constraint FK_Doctor_IdDoctores
    foreign key(idDoctor)
    references doctores(id);

alter table turnos
    add constraint FK_Paciente_IdPacientes
    foreign key(idPaciente)
    references pacientes(id);

alter table especialidades
    add constraint FK_Doctor_IdDoctor
    foreign key(id)
    references doctores(id);