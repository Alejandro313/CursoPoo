use sanatorio;

-- Lista de pacientes del doctor con id 1
select * from paciente where turnoID = 1; 

-- Lista de paciente de la odontologa Miranda Melo 

-- Cual es el listado de pacientes de cardiologia y de gastroenterologo?
select p.id, a.nombre, p.apellido, p.turnoID, p.dia_y_horario

-- Cual es listado de pacientes de odontologia con horarios menores a 10 am?

-- Que turno tiene el paciente brian gimenez?

-- Cual es el nombre de los medicos del dia lunes y cuales son sus pacientes?

-- Que medicos estan atendiendo en turno tarde?

-- Que medicos estan atendiendo en turno mañana?