use sanatorio;

-- Cual es el numero de telefono y la direccion del sanatorio?
select telefono, direccion from institucion;

-- Que medicos estan atendiendo en turno mañana?
select nombre,apellido from doctores where turno = 'MAÑANA';

-- Que medicos estan atendiendo en turno tarde?
select nombre,apellido from doctores where turno = 'TARDE';

-- Lista de pacientes del doctor con id 1
select p.nombre, p.apellido, p.edad from paciente p join doctores d on p.od = d.id
like d.id=1;

-- Lista de paciente de la odontologa Miranda Melo 
select p.nombre, p.apellido,p.dia_y_horario
from paciente p join doctor d on p.turnoID = d.id
where d.nombre = 'Miranda' and d.apellido = 'Melo';

-- Cual es el listado de pacientes de neumologia?
select p.nombre, p.apellido, p.dia_y_horario
from paciente p join doctor d on p.turnoID = d.id
where d.especialidad = 'Neumologia';

-- Quienes son medicos cardiologos?
select * from doctor where especialidad = 'Cardiologia';

-- Que horario de atencion tiene el paciente brian gimenez?
select p.dia_y_horario from paciente p join doctor d on p.turnoID = d.id
where p.nombre = 'Brian' and p.apellido = 'Gimenez';

-- Cual es el nombre de los medicos del dia lunes, cuales son sus pacientes y cual es el horario de atencion?
select d.dia, d.nombre, p.nombre, p.apellido, p.dia_y_horario 
from doctor d join paciente p on d.id=p.turnoID
where d.dia = 'LUNES';

