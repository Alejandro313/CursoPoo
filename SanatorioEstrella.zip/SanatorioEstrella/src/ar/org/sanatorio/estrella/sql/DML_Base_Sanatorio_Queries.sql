use sanatorio;

-- Cual es el numero de telefono y la direccion del sanatorio?
select telefono, direccion from institucion;

-- cuantas especialidades tiene el sanatorio?
select count(*) cantidad_de_especializaciones
    from especialidades join institucion;

-- Que medicos estan atendiendo en turno mañana?
select nombre,apellido from doctores where turno = 'MAÑANA';

-- Que medicos estan atendiendo en turno tarde?
select nombre,apellido from doctores where turno = 'TARDE';

-- cuales son las especializaciones, el nombre y apellido de los doctores?
select d.id,e.especialidad , d.nombre, d.apellido
from doctores d join especialidades e on d.id=e.id;

-- Lista de nombre, apellido, edad y dni de los pacientes del doctor Mariano lopez
select p.id,p.nombre, p.apellido, p.edad, p.dni
from pacientes p join turnos t on p.id=t.idPaciente join doctores d on d.id=t.idDoctor
where d.nombre="Mariano" and d.apellido="Lopez";

-- Lista de paciente con horario y fecha de la odontologa Miranda Melo 
select p.nombre, p.apellido, p.edad, t.fecha, t.horario
from pacientes p join turnos t on p.id=t.idPaciente join doctores d on d.id=t.idDoctor
where d.nombre="Miranda" and d.apellido="Melo";

-- Cual es el listado de pacientes de neumologia?
select p.nombre, p.apellido, p.edad, t.fecha, t.horario
from pacientes p join turnos t on p.id=t.idPaciente join doctores d on d.id=t.idDoctor join especialidades e on e.id=d.id
where e.especialidad="NEUMOLOGIA";	

-- Quienes son medicos cardiologos?
select d.nombre, d.apellido
from doctores d join especialidades e on d.id=e.id
where e.especialidad="CARDIOLOGIA";

-- Que fecha y horario de atencion tiene el paciente Patricio Ledezma?
select p.nombre, p.apellido, t.fecha, t.horario, e.especialidad
from pacientes p join turnos t on p.id=t.idPaciente join especialidades e on e.id=p.id
where p.nombre="Patricio" and p.apellido="Ledezma";

-- Mostrar a los medicos, su especialidad y sus pacientes, con todos sus datos, con la fecha y horario de atencion 
select d.nombre, d.dia, p.nombre, p.apellido, p.edad, p.dni, p.obra_social, t.fecha, t.horario
from doctores d join turnos t on d.id=t.idDoctor join pacientes p on p.id=t.idPaciente;