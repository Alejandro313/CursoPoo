use sanatorio;

select * from institucion;
select * from turnos;
select * from doctores;
select * from pacientes;

insert into institucion (nombre, cuit, telefono, direccion, horarios) values
('Sanatorio Estrella','30-67546356',42765434,'San Martin 503','24 horas');

insert into doctores (nombre,apellido,dia,turno) values
('Mariano','Lopez','LUNES','MAÑANA'),
('Oscar','Deluca','MARTES','MAÑANA'),
('Carla','Morales','LUNES','MAÑANA'),
('Micaela','Sanchez','JUEVES','TARDE'),
('Martin','Perez','MIERCOLES','TARDE'),
('Miranda','Melo','VIERNES','MAÑANA'),
('Cesar','Cazula','SABADO','MAÑANA');

insert into especialidades (especialidad) values
('GASTROENTEROLOGIA'),
('CARDIOLOGIA'),
('PEDIATRIA'),
('NEUMOLOGIA'),
('CARDIOLOGIA'),
('ODONTOLOGIA'),
('OFTALMOLOGIA');

insert into turnos(idDoctor,idPaciente,fecha,horario) values
(6,1,'2021-06-04','11:00'),
(4,1,'2021-06-10','12:00'),
(2,2,'2021-06-09','08:00'),
(6,2,'2021-06-11','10:00'),
(1,3,'2021-06-07','09:00'),
(5,3,'2021-06-16','15:00'),
(3,4,'2021-06-14','11:00'),
(1,4,'2021-06-07','11:00'),
(5,5,'2021-06-16','15:00'),
(2,5,'2021-06-09','11:00'),
(4,6,'2021-06-10','12:00');

insert into pacientes(nombre,apellido,edad,dni,obra_social) values
('Julieta','Pascal',28,34876754,'vital'),
('Miguel','Diaz',24,41874534,'Ceramista'),
('Julian','Mendoza',18,44587594,'Borge'),
('Rodrigo','Palacio',12,45876745,'DIG'),
('Patricio','Ledezma',17,44987865,'Rido'),
('David','Merendez',32,27987657,'Vista'),
('Monica','Silva',29,34765434,'Naranja A'),
('Dante','Rios',31,26876754,'Conten'),
('Diana','Fernandez',25,35787654,'Derecha B'),
('Sandro','Galvan',24,36875643,'Izquierda H'),
('Sebastian','Molina',36,25432654,'Celeste D'),
('Brian','Gimenez',40,24765734,'Marmol SR');