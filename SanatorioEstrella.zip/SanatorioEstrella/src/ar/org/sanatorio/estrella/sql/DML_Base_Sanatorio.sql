use sanatorio;

select * from doctor;
select * from paciente;

insert into doctor (especialidad,nombre,apellido,dia,turno) values
('Gastroenterologia','Mariano','Lopez','LUNES','MAÑANA'),
('Cardiologia','Oscar','Deluca','MARTES','MAÑANA'),
('Pediatria','Carla','Morales','LUNES','MAÑANA'),
('Neumologia','Micaela','Sanchez','JUEVES','TARDE'),
('Cardiologia','Martin','Perez','MIERCOLES','TARDE'),
('Odontologia','Miranda','Melo','VIERNES','MAÑANA'),
('Oftalmologia','Cesar','Cazula','SABADO','MAÑANA');

insert into paciente (nombre,apellido,turnoID,dia_y_horario) values
('Julieta','Pascal',3,'2021-05-31 09:20:00'),
('Miguel','Diaz',2,'2021-06-02 11:00:00'),
('Julian','Mendoza',4,'2021-06-03 13:00:00'),
('Rodrigo','Palacio',6,'2021-06-04 08:30:00'),
('Patricio','Ledezma',7,'2021-06-05 10:30:00'),
('David','Merendez',1,'2021-06-07 07:40:00'),
('Monica','Silva',4,'2021-06-31 14:00:00'),
('Dante','Rios',7,'2021-06-05 11:00:00'),
('Diana','Fernandez',3,'2021-06-07 10:10:00'),
('Sandro','Galvan',6,'2021-06-04 09:30:00'),
('Sebastian','Molina',1,'2021-06-07 08:30:00'),
('Brian','Gimenez',6,'2021-06-04 10:20:00');
