package ar.org.sanatorio.estrella.enums;


public class Especialidad {
   
    public enum especialidad{Cardiologia,Gastroenterologia,Endocrinologia,Neumologia,Odontologia,Otorrinolaringologia,Oftalmologia,Pediatria}
}
