package ar.org.sanatorio.estrella.enums;


public class Dia {
    
    public enum dia{LUNES,MARTES,MIERCOLES,JUEVES,VIERNES,SABADO,DOMINGO}
}
