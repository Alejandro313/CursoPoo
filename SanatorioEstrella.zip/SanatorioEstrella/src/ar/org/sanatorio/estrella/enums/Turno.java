package ar.org.sanatorio.estrella.enums;


public class Turno {
    
    public enum turno{MAÑANA,TARDE}
}
