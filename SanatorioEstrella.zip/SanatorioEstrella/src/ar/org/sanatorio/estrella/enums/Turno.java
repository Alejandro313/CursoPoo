package ar.org.sanatorio.estrella.enums;


public enum Turno {MAA�ANA,TARDE}
