package ar.org.sanatorio.estrella.enums;


public enum DiaTurno {MAÑANA,TARDE}
