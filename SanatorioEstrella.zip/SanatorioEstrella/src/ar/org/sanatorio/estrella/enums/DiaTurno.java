package ar.org.sanatorio.estrella.enums;


public enum DiaTurno {MA�ANA,TARDE}
