package ar.org.sanatorio.estrella.connectors;
import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
   private static String driver = "org.mariadb.jdbc.Driver"; 
   private static String vendor = "mariadb";
   
   //                                                  Servidor Local
   
   /*private static String server = "localhost";
   private static String port = "3306";
   private static String bd = "sanatorio";
   private static String params = "?serverTimezone=UTC";
   private static String user = "root";
   private static String pass = "";*/
   
   //                                                  Servidor Remoto
   private static String server = "freedb.tech";
   private static String port = "3306";
   private static String bd = "freedbtech_sanatorio";
   private static String params = "";
   private static String user = "freedbtech_freedbsanatorio";
   private static String pass = "estrella";
   
 //url del servidor
   private static String url="jdbc:"+vendor+"://"+server+":"+port+"/"+bd+params;
   
 //objeto para la coneccion
   private static Connection conn=null;
   
   private Connector(){}
   
   public synchronized static Connection getConnection(){
       try {
           if(conn==null||conn.isClosed()){
               
           Class.forName(driver);
           
           conn=DriverManager.getConnection(url,user,pass);
           }
       } catch (Exception e) {
           System.out.println(e);
       }
       return conn;
   }
}