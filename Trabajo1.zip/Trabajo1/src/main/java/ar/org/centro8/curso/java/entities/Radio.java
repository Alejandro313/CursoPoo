package ar.org.centro8.curso.java.entities;

public class Radio {
    
    private String Marca;

    public Radio(String Marca) {
        this.Marca = Marca;
    }
    
    public String getMarca() {
        return Marca;
    }
    
    @Override
    public String toString() {
        return "Radio Marca= " + Marca;
    }    

}
