package ar.org.centro8.curso.java.entities;

public class autoClasico extends Vehiculo {
    
    private Radio radio;
    /**
     * Un Auto Clásico se puede fabricar sin radio
     */
    
    public autoClasico(String Color, String Marca, String Modelo, float Precio) {
        super(Color, Marca, Modelo, Precio);
    }

    /**
     * después se puede agregar una radio.
     */

    @Override
    public void implementarRadio(String Marca) {
         radio = new Radio(Marca);
    }
  
    @Override
    public String toString() {
        return "Auto Clasico: " + super.toString() + "\n" +radio;
    }   
    
}
