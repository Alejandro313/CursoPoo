package ar.org.centro8.curso.java.entities;

public abstract class Vehiculo {
    
    private String Color;
    private String Marca;
    private String Modelo;
    private float Precio;

    
    public Vehiculo(String Color, String Marca, String Modelo, float Precio) {
        this.Color = Color;
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Precio = Precio;
    }
    
    @Override
    public String toString() {
        return "Vehiculo" + "\nColor= " + Color + "\nMarca=" + Marca + "\nModelo= " + Modelo + "\nPrecio= " + Precio;
    }

    public float getPrecio() {
        return Precio;
    }

    public void setPrecio(float Precio) {
        this.Precio = Precio;
    }

    public String getColor() {
        return Color;
    }

    public String getMarca() {
        return Marca;
    }

    public String getModelo() {
        return Modelo;
    }
    
    public abstract void implementarRadio(String Marca);

}
