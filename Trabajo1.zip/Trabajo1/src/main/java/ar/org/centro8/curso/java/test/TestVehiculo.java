package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.autoClasico;
import ar.org.centro8.curso.java.entities.autoNuevo;

public class TestVehiculo {
    
    public static void main(String[] args) {
        
        //  -- Autos clasico -- 
        autoClasico v1 = new autoClasico("Rojo","Renault","zoe",15000);
        autoClasico v2 = new autoClasico("Negro","Fiat","Cronos",11000);
        autoClasico v3 = new autoClasico("Amarillo","Chevy","SS",12000);
        
        v1.implementarRadio("Alpine");
        v2.implementarRadio("Pionner");
        System.out.println(v1.toString()+"\n");
        System.out.println(v2.toString()+"\n");
        System.out.println(v3.toString()+"\n");
       
        //-- Autos Nuevos --
      autoNuevo a1 = new autoNuevo("Blanco","BMW","i8",30000,"Pionner");
      autoNuevo a2 = new autoNuevo("Azul","Chevrolet","Cruze",17000,"Sony MEX");
      autoNuevo a3 = new autoNuevo("Gris","Mercedes Benz","A200",28000,"Boss A25");
      
     
      a1.implementarRadio("Alpine");
      a2.implementarRadio("Pionner");
      System.out.println(a1.toString()+"\n");
      System.out.println(a2.toString()+"\n");
      System.out.println(a3.toString());
    }
}
