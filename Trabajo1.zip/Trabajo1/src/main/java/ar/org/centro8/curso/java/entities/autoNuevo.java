package ar.org.centro8.curso.java.entities;


public class autoNuevo extends Vehiculo {
    
    private Radio radio;
 /**
  * Un Auto Nuevo siempre tiene radio  
  */
    public autoNuevo(String Color, String Marca, String Modelo, float Precio,String Radio) {
        super(Color, Marca, Modelo, Precio);
        this.radio = new Radio(Marca);
    }
    
    /**
     * Y se puede cambiar de radio
     */
    
    @Override
    public void implementarRadio(String Marca) {
        radio = new Radio(Marca);
    }

    @Override
    public String toString() {
        return "Auto Nuevo: " + super.toString() + "\n" +radio;
    }
    
}
