package Parte19.ar.org.centro8.curso.java.enums;


public enum Turno {MAÑANA,TARDE,NOCHE}

