package Parte19.ar.org.centro8.curso.java.repositories.interfaces;

import Parte19.ar.org.centro8.curso.java.entities.Curso;
import Parte19.ar.org.centro8.curso.java.enums.Dia;
import java.util.List;

public interface I_CursoRepository {
    void save(Curso curso); //Con el metodo save guardamos un curso
    void remove(Curso curso); //Borra el archivo
    void update(Curso curso); //Actualiza
    Curso getById(int id); //Busca un id del archivo
    List<Curso>getAll(); //Devuelve una coleccion de curso
    List<Curso>getLikeTiulo(String titulo); //Devuelve listado de curso que tengan considencia
    List<Curso>getLikeTituloProfesor(String titulo, String profesor);
    List<Curso>getByDia(Dia dia); //Ingresa un dia
    
}
