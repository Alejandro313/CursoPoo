package Parte19.ar.org.centro8.curso.java.connectors;
import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    private static String driver="org.mariadb.jdbc.Driver"; //llamamos al driver que se encuentra en mariaDB.jdbc
    private static String vendor="mariadb"; //Indicamos que vendor, el fabricante del driver es mariadb
    //private static String server="localhost"; //Servidor local
    private static String server="freedb.tech"; //Servidor remoto
    private static String port="3306"; //Puerto de coneccion a mysql
    //private static String bd="colegio"; //Nombre de la base de dato local
    private static String bd="freedbtech_colegio"; // Nombre de la base de datos remota
    //private static String params="?serverTimezone=UTC"; //Parametro local
    private static String params=""; //Parametro local
    //private static String user="root";
    private static String user="freedbtech_colegio";
    //private static String pass=""; //contrase�a local
    private static String pass="colegio"; //contrase�a remota
   
    //Url del servidor
    private static String url="jdbc:"+vendor+"://"+server+":"+port+"/"+bd+params;
    
    //Objeto para la coneccion
    private static Connection conn=null;
    
    //Para importar la coneccion debemos elegir trabajar dentro del paquete del driver que tengamos
    //Se debe centralizar todo en una sola coneccion (Es preferible)
    
    private Connector(){}
  
    //Unico elemento de miembro publico estatico que devuelve un objeto conection "getConection()" 
    public synchronized static Connection getConnection(){
        //synchronized: Si alguien crea una coneccion y otro proceso quiere entrar va tener que esperar a que el primero termine para evitar conecciones paralelas.
    	//patron de dise�o singleton
    	//agregamos una exception
    	try {
    		//Si la coneccion es nula o esta cerrada, la creo
            if(conn==null || conn.isClosed()){
            //Creamos la coneccion
            	//registramos la clase driver, le indicamos que existe la clase driver
            	Class.forName(driver);
            	
            	//Importamos el driver manager
            	//agregamos con manager y decimos que devuelva la url, user,pass
                conn=DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    } 
    
    //Si no es nula salta a conn y devuelve la coneccion creada/indicada.
    //Si la coneccion esta cerrada, entonces la crea/indica y la devuelve en return conn

}
