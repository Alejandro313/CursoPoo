-- use colegio;
select version();

-- Listado de alumnos del curso id 1?
select * from alumnos where idCurso=1;

-- A que curso asiste Lorena Farias?
select c.id, c.titulo, c.profesor, c.dia, c.turno
    from alumnos a join cursos c on a.idCurso=c.id
    where a.nombre='Lorena' and a.apellido='Farias';

-- Listado de Alumnos que estudian Java?
select a.id, a.nombre, a.apellido, a.edad, a.idCurso, c.titulo, c.dia, c.turno
    from alumnos a join cursos c on a.idCurso=c.id
    where titulo='Java';

-- Listado de Alumnos del que estudian en turno tarde?
select a.id, a.nombre, a.apellido, a.edad, a.idCurso, c.titulo, c.dia, c.turno
    from alumnos a join cursos c on a.idCurso=c.id
    where c.turno='TARDE';

-- Cantidad de alumnos del profesor Gomez?
select count(*) cantidad_alumnos
    from alumnos a join cursos c on a.idCurso=c.id
    where c.profesor='Gomez';
